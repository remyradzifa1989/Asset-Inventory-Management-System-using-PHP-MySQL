<?php
// =====================================================
// AIMS - Database & App Config
// =====================================================

define('DB_HOST', 'localhost:3306');
define('DB_USER', 'aims_db');
define('DB_PASS', 'VMPRODpass!@4');
define('DB_NAME', 'admin_aims');

define('APP_NAME', 'AIMS');
define('APP_FULL', 'Asset Inventory Management System');

// BASE_URL — adjust to your install path, e.g. http://localhost/aims/
$proto = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
$host  = $_SERVER['HTTP_HOST'] ?? 'localhost';
$base  = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
// Strip module subdir (auth, assets, borrow, ...) so BASE_URL = project root
$base  = preg_replace('#/(auth|assets|borrow|maintenance|reports|users|ajax|api)$#', '', $base);
define('BASE_URL', $proto . '://' . $host . $base . '/');

define('UPLOAD_DIR', __DIR__ . '/../uploads/');
define('UPLOAD_URL', BASE_URL . 'uploads/');

date_default_timezone_set('Asia/Kuala_Lumpur');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// MySQLi connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die('Database connection failed: ' . $conn->connect_error);
}
$conn->set_charset('utf8mb4');

// Helpers
function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }

function require_login() {
    if (empty($_SESSION['user_id'])) {
        header('Location: ' . BASE_URL . 'auth/login.php');
        exit;
    }
}

function require_admin() {
    require_login();
    if (($_SESSION['role'] ?? '') !== 'ADMIN') {
        http_response_code(403);
        die('Access denied. Admin only.');
    }
}

function current_user() {
    return [
        'id'       => $_SESSION['user_id']  ?? null,
        'fullname' => $_SESSION['fullname'] ?? '',
        'username' => $_SESSION['username'] ?? '',
        'role'     => $_SESSION['role']     ?? '',
    ];
}

function log_activity($user_id, $action, $description = '') {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO activity_logs (user_id, action, description) VALUES (?, ?, ?)");
    $stmt->bind_param('iss', $user_id, $action, $description);
    $stmt->execute();
    $stmt->close();
}

function flash_set($key, $msg) { $_SESSION['flash'][$key] = $msg; }
function flash_get($key) {
    if (!empty($_SESSION['flash'][$key])) {
        $m = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $m;
    }
    return null;
}
