<?php
require_once __DIR__ . '/config.php';
require_login();
$user = current_user();
$active = $active ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($page_title ?? APP_NAME) ?> · <?= APP_NAME ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.7/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" href="<?= BASE_URL ?>assets_static/css/style.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="aims-body">
<div class="aims-layout">
  <aside class="aims-sidebar">
    <div class="sb-brand">
      <div class="sb-logo"><i class="bi bi-boxes"></i></div>
      <div>
        <div class="sb-title">AIMS</div>
        <div class="sb-sub">Asset Inventory</div>
      </div>
    </div>
    <nav class="sb-nav">
      <a href="<?= BASE_URL ?>dashboard.php" class="<?= $active==='dashboard'?'active':'' ?>"><i class="bi bi-speedometer2"></i> Dashboard</a>
      <a href="<?= BASE_URL ?>assets/list.php" class="<?= $active==='assets'?'active':'' ?>"><i class="bi bi-pc-display"></i> Assets</a>
      <a href="<?= BASE_URL ?>borrow/list.php" class="<?= $active==='borrow'?'active':'' ?>"><i class="bi bi-arrow-left-right"></i> Borrow Records</a>
      <a href="<?= BASE_URL ?>maintenance/list.php" class="<?= $active==='maintenance'?'active':'' ?>"><i class="bi bi-tools"></i> Maintenance</a>
      <a href="<?= BASE_URL ?>reports/index.php" class="<?= $active==='reports'?'active':'' ?>"><i class="bi bi-bar-chart-line"></i> Reports</a>
      <?php if ($user['role']==='ADMIN'): ?>
      <div class="sb-section">Administration</div>
      <a href="<?= BASE_URL ?>users/list.php" class="<?= $active==='users'?'active':'' ?>"><i class="bi bi-people"></i> Users</a>
      <a href="<?= BASE_URL ?>reports/activity.php" class="<?= $active==='activity'?'active':'' ?>"><i class="bi bi-journal-text"></i> Activity Logs</a>
      <?php endif; ?>
    </nav>
    <div class="sb-foot">
      <div class="sb-user">
        <div class="sb-avatar"><?= strtoupper(substr($user['fullname'],0,1)) ?></div>
        <div>
          <div class="sb-name"><?= e($user['fullname']) ?></div>
          <div class="sb-role"><?= e($user['role']) ?></div>
        </div>
      </div>
      <a href="<?= BASE_URL ?>auth/logout.php" class="sb-logout"><i class="bi bi-box-arrow-right"></i></a>
    </div>
  </aside>
  <main class="aims-main">
    <header class="aims-topbar">
      <button class="btn btn-light btn-sm d-md-none" id="sbToggle"><i class="bi bi-list"></i></button>
      <div class="topbar-title"><?= e($page_title ?? 'Dashboard') ?></div>
      <div class="topbar-actions">
        <button class="btn btn-light btn-sm" id="darkToggle" title="Toggle theme"><i class="bi bi-moon-stars"></i></button>
        <span class="badge text-bg-primary"><?= e($user['role']) ?></span>
      </div>
    </header>
    <section class="aims-content">

      <?php $flash_ok = flash_get('ok'); $flash_err = flash_get('err'); ?>
      <?php if ($flash_ok): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
          <i class="bi bi-check-circle-fill me-2"></i><?= e($flash_ok) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>
      <?php if ($flash_err): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
          <i class="bi bi-exclamation-triangle-fill me-2"></i><?= e($flash_err) ?>
          <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
      <?php endif; ?>
