-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2026 at 11:25 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `aims_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity_logs`
--

CREATE TABLE `activity_logs` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `activity_logs`
--

INSERT INTO `activity_logs` (`id`, `user_id`, `action`, `description`, `created_at`) VALUES
(1, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-13 16:32:31'),
(2, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-13 16:32:57'),
(3, 4, 'ASSET_UPDATE', 'Updated asset #3', '2026-05-13 16:38:30'),
(4, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-13 16:38:47'),
(5, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-13 16:39:10'),
(6, 4, 'ASSET_UPDATE', 'Updated asset #3', '2026-05-13 16:40:52'),
(7, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-13 16:56:30'),
(8, 4, 'BORROW_CREATE', 'Borrow record for asset #2', '2026-05-14 08:48:33'),
(9, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 08:49:55'),
(10, 4, 'BORROW_CREATE', 'Borrow record for asset #1', '2026-05-14 08:50:41'),
(11, 4, 'BORROW_RETURN', 'Returned borrow #2', '2026-05-14 08:51:29'),
(12, 4, 'MAINT_CREATE', 'Maintenance for asset #3', '2026-05-14 08:52:25'),
(13, 4, 'MAINT_COMPLETE', 'Completed maintenance #1', '2026-05-14 08:52:51'),
(14, 4, 'ASSET_CREATE', 'Created asset #4', '2026-05-14 09:40:24'),
(15, 4, 'ASSET_UPDATE', 'Updated asset #4', '2026-05-14 09:46:47'),
(16, 4, 'ASSET_CREATE', 'Created asset #5', '2026-05-14 09:57:02'),
(17, 4, 'ASSET_DELETE', 'Deleted asset #5', '2026-05-14 10:03:48'),
(18, 4, 'ASSET_DELETE', 'Deleted asset #4', '2026-05-14 10:03:51'),
(19, 4, 'ASSET_CREATE', 'Created asset #6', '2026-05-14 10:33:03'),
(20, 4, 'ASSET_DELETE', 'Deleted asset #6', '2026-05-14 10:34:38'),
(21, 4, 'ASSET_CREATE', 'Created asset #7', '2026-05-14 10:37:11'),
(22, 4, 'ASSET_CREATE', 'Created asset #8', '2026-05-14 10:45:37'),
(23, 4, 'BORROW_DELETE', 'Deleted borrow #1', '2026-05-14 10:52:44'),
(24, 4, 'BORROW_DELETE', 'Deleted borrow #2', '2026-05-14 10:52:47'),
(25, 4, 'ASSET_DELETE', 'Deleted asset #8', '2026-05-14 12:24:52'),
(26, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 12:26:16'),
(27, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 12:28:46'),
(28, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 12:37:37'),
(29, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 12:38:21'),
(30, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 12:38:48'),
(31, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 12:47:09'),
(32, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 12:47:28'),
(33, 4, 'ASSET_CREATE', 'Created asset #9', '2026-05-14 12:48:16'),
(34, 4, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 12:48:28'),
(35, 4, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 12:48:48'),
(36, 4, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 12:51:40'),
(37, 4, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 12:59:44'),
(38, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 12:59:55'),
(39, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 14:48:14'),
(40, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:02:46'),
(41, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:02:57'),
(42, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:03:07'),
(43, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:03:44'),
(44, 4, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 15:03:58'),
(45, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:04:08'),
(46, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:04:16'),
(47, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:04:26'),
(48, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:06:20'),
(49, 4, 'ASSET_UPDATE', 'Updated asset #3', '2026-05-14 15:06:32'),
(50, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:06:54'),
(51, 4, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 15:07:09'),
(52, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:07:41'),
(53, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:07:54'),
(54, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:08:08'),
(55, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:08:38'),
(56, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:08:58'),
(57, 4, 'ASSET_UPDATE', 'Updated asset #3', '2026-05-14 15:09:14'),
(58, 4, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 15:09:26'),
(59, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:10:13'),
(60, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:21:31'),
(61, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:22:47'),
(62, 4, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:22:55'),
(63, 4, 'ASSET_UPDATE', 'Updated asset #3', '2026-05-14 15:23:04'),
(64, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:23:55'),
(65, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:24:03'),
(66, 4, 'ASSET_UPDATE', 'Updated asset #3', '2026-05-14 15:47:02'),
(67, 4, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:47:13'),
(68, 4, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:53:28'),
(69, 4, 'LOGOUT', 'User logged out', '2026-05-14 15:55:20'),
(70, 1, 'LOGIN', 'User logged in', '2026-05-14 15:57:12'),
(71, 1, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:57:32'),
(72, 1, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:57:40'),
(73, 1, 'ASSET_UPDATE', 'Updated asset #1', '2026-05-14 15:57:52'),
(74, 1, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 15:57:58'),
(75, 1, 'ASSET_UPDATE', 'Updated asset #3', '2026-05-14 15:58:10'),
(76, 1, 'ASSET_UPDATE', 'Updated asset #7', '2026-05-14 15:58:17'),
(77, 1, 'ASSET_UPDATE', 'Updated asset #9', '2026-05-14 15:58:25'),
(78, 1, 'ASSET_CREATE', 'Created asset #10', '2026-05-14 15:58:43'),
(79, 1, 'ASSET_CREATE', 'Created asset #11', '2026-05-14 16:16:29'),
(80, 1, 'ASSET_DELETE', 'Deleted asset #12', '2026-05-14 16:33:20'),
(81, 1, 'ASSET_DELETE', 'Deleted asset #11', '2026-05-14 16:33:24'),
(82, 1, 'ASSET_CREATE', 'Created asset #17', '2026-05-14 16:33:47'),
(83, 1, 'ASSET_UPDATE', 'Updated asset #17', '2026-05-14 16:34:25'),
(84, 1, 'ASSET_UPDATE', 'Updated asset #17', '2026-05-14 16:34:36'),
(85, 1, 'ASSET_UPDATE', 'Updated asset #17', '2026-05-14 16:41:36'),
(86, 1, 'ASSET_UPDATE', 'Updated asset #2', '2026-05-14 16:41:53'),
(87, 1, 'ASSET_CREATE', 'Created asset #18', '2026-05-14 17:06:38'),
(88, 1, 'BORROW_CREATE', 'Borrow record for asset #18', '2026-05-14 17:07:21'),
(89, 1, 'ASSET_DELETE', 'Deleted asset #18', '2026-05-14 17:20:19'),
(90, 1, 'ASSET_DELETE', 'Deleted asset #17', '2026-05-14 17:20:23'),
(91, 1, 'ASSET_DELETE', 'Deleted asset #10', '2026-05-14 17:20:26'),
(92, 1, 'ASSET_DELETE', 'Deleted asset #9', '2026-05-14 17:20:29'),
(93, 1, 'ASSET_DELETE', 'Deleted asset #7', '2026-05-14 17:20:51'),
(94, 1, 'ASSET_DELETE', 'Deleted asset #3', '2026-05-14 17:24:59'),
(95, 1, 'ASSET_DELETE', 'Deleted asset #2', '2026-05-14 17:25:01'),
(96, 1, 'ASSET_DELETE', 'Deleted asset #1', '2026-05-14 17:25:03');

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `asset_code` varchar(80) NOT NULL,
  `asset_name` varchar(200) NOT NULL,
  `asset_category` varchar(100) DEFAULT NULL,
  `serial_number` varchar(150) DEFAULT NULL,
  `brand` varchar(120) DEFAULT NULL,
  `model` varchar(120) DEFAULT NULL,
  `motherboard` varchar(150) DEFAULT NULL,
  `cpu` varchar(150) DEFAULT NULL,
  `ram` varchar(100) DEFAULT NULL,
  `storage` varchar(150) DEFAULT NULL,
  `gpu` varchar(150) DEFAULT NULL,
  `psu` varchar(120) DEFAULT NULL,
  `monitor` varchar(150) DEFAULT NULL,
  `keyboard` varchar(120) DEFAULT NULL,
  `mouse` varchar(120) DEFAULT NULL,
  `os` varchar(120) DEFAULT NULL,
  `use_by` varchar(150) DEFAULT NULL,
  `department` varchar(120) DEFAULT NULL,
  `building` varchar(120) DEFAULT NULL,
  `floor` varchar(50) DEFAULT NULL,
  `location` varchar(150) DEFAULT NULL,
  `manufacturer_year` varchar(10) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `warranty_date` date DEFAULT NULL,
  `status` enum('Available','Used By','Borrowed','Maintenance','Damaged','Disposed') NOT NULL DEFAULT 'Available',
  `image` varchar(255) DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `hardware_spec_new` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`hardware_spec_new`)),
  `hardware_spec` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`hardware_spec`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `asset_files`
--

CREATE TABLE `asset_files` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `original_name` varchar(255) DEFAULT NULL,
  `file_type` varchar(50) DEFAULT NULL,
  `uploaded_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `borrow_records`
--

CREATE TABLE `borrow_records` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `borrow_by` varchar(150) NOT NULL,
  `department` varchar(120) DEFAULT NULL,
  `borrow_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `actual_return_date` date DEFAULT NULL,
  `status` enum('Pending','Approved','Returned','Late Return') NOT NULL DEFAULT 'Pending',
  `remarks` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_records`
--

CREATE TABLE `maintenance_records` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `technician` varchar(150) NOT NULL,
  `problem` text NOT NULL,
  `maintenance_date` date NOT NULL,
  `cost` decimal(10,2) DEFAULT 0.00,
  `status` enum('Pending','In Progress','Completed') NOT NULL DEFAULT 'Pending',
  `remarks` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullname` varchar(150) NOT NULL,
  `username` varchar(80) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('ADMIN','STAFF') NOT NULL DEFAULT 'STAFF',
  `department` varchar(120) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullname`, `username`, `password`, `role`, `department`, `email`, `created_at`) VALUES
(1, 'System Administrator', 'admin', '$2y$10$2rhLvPbPEcHmgAScFsH5T.RKaEsK/8tsaAcvtA01wbA.BPxSFuMn2', 'ADMIN', 'IT', 'admin@company.com', '2026-05-13 09:41:02'),
(2, 'Staff Demo', 'staff', '$2y$10$vIF.1H7gRh7ZsCuJR2aVJ.YqNtrN8vGUne.ymSpRM8H7lFVn5wN2W', 'STAFF', 'Operations', 'staff@company.com', '2026-05-13 09:41:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity_logs`
--
ALTER TABLE `activity_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `asset_code` (`asset_code`);

--
-- Indexes for table `asset_files`
--
ALTER TABLE `asset_files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `borrow_records`
--
ALTER TABLE `borrow_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `maintenance_records`
--
ALTER TABLE `maintenance_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity_logs`
--
ALTER TABLE `activity_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `asset_files`
--
ALTER TABLE `asset_files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `borrow_records`
--
ALTER TABLE `borrow_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `maintenance_records`
--
ALTER TABLE `maintenance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `asset_files`
--
ALTER TABLE `asset_files`
  ADD CONSTRAINT `asset_files_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `borrow_records`
--
ALTER TABLE `borrow_records`
  ADD CONSTRAINT `borrow_records_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `maintenance_records`
--
ALTER TABLE `maintenance_records`
  ADD CONSTRAINT `maintenance_records_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
