-- =====================================================
-- AIMS - Asset Inventory Management System
-- MySQL Database Schema
-- =====================================================

CREATE DATABASE IF NOT EXISTS aims_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE aims_db;

-- ---------------------------
-- USERS
-- ---------------------------
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fullname VARCHAR(150) NOT NULL,
    username VARCHAR(80) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('ADMIN','STAFF') NOT NULL DEFAULT 'STAFF',
    department VARCHAR(120) DEFAULT NULL,
    email VARCHAR(150) DEFAULT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Default users (password: admin123 / staff123)
INSERT INTO users (fullname, username, password, role, department, email) VALUES
('System Administrator', 'admin', '$2y$10$e0NRyJgQ8C1Q6m1H3n3Y9eR1m1vH3p1fO5Wq.Q2r0xH4m7QaG2eMK', 'ADMIN', 'IT', 'admin@company.com'),
('Staff Demo', 'staff', '$2y$10$e0NRyJgQ8C1Q6m1H3n3Y9eR1m1vH3p1fO5Wq.Q2r0xH4m7QaG2eMK', 'STAFF', 'Operations', 'staff@company.com');
-- NOTE: After install, run /auth/reset_passwords.php once to set proper hashes for admin123 / staff123

-- ---------------------------
-- ASSETS
-- ---------------------------
CREATE TABLE IF NOT EXISTS assets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_code VARCHAR(80) NOT NULL UNIQUE,
    asset_name VARCHAR(200) NOT NULL,
    asset_category VARCHAR(100) DEFAULT NULL,
    serial_number VARCHAR(150) DEFAULT NULL,
    brand VARCHAR(120) DEFAULT NULL,
    model VARCHAR(120) DEFAULT NULL,
    motherboard VARCHAR(150) DEFAULT NULL,
    cpu VARCHAR(150) DEFAULT NULL,
    ram VARCHAR(100) DEFAULT NULL,
    storage VARCHAR(150) DEFAULT NULL,
    gpu VARCHAR(150) DEFAULT NULL,
    psu VARCHAR(120) DEFAULT NULL,
    monitor VARCHAR(150) DEFAULT NULL,
    keyboard VARCHAR(120) DEFAULT NULL,
    mouse VARCHAR(120) DEFAULT NULL,
    os VARCHAR(120) DEFAULT NULL,
    use_by VARCHAR(150) DEFAULT NULL,
    department VARCHAR(120) DEFAULT NULL,
    building VARCHAR(120) DEFAULT NULL,
    floor VARCHAR(50) DEFAULT NULL,
    location VARCHAR(150) DEFAULT NULL,
    manufacturer_year VARCHAR(10) DEFAULT NULL,
    purchase_date DATE DEFAULT NULL,
    warranty_date DATE DEFAULT NULL,
    status ENUM('Available','Borrowed','Maintenance','Damaged','Disposed') NOT NULL DEFAULT 'Available',
    image VARCHAR(255) DEFAULT NULL,
    remarks TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------
-- ASSET FILES (attachments)
-- ---------------------------
CREATE TABLE IF NOT EXISTS asset_files (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    original_name VARCHAR(255) DEFAULT NULL,
    file_type VARCHAR(50) DEFAULT NULL,
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------
-- BORROW RECORDS
-- ---------------------------
CREATE TABLE IF NOT EXISTS borrow_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    borrow_by VARCHAR(150) NOT NULL,
    department VARCHAR(120) DEFAULT NULL,
    borrow_date DATE NOT NULL,
    return_date DATE DEFAULT NULL,
    actual_return_date DATE DEFAULT NULL,
    status ENUM('Pending','Approved','Returned','Late Return') NOT NULL DEFAULT 'Pending',
    remarks TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------
-- MAINTENANCE RECORDS
-- ---------------------------
CREATE TABLE IF NOT EXISTS maintenance_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    asset_id INT NOT NULL,
    technician VARCHAR(150) NOT NULL,
    problem TEXT NOT NULL,
    maintenance_date DATE NOT NULL,
    cost DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('Pending','In Progress','Completed') NOT NULL DEFAULT 'Pending',
    remarks TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (asset_id) REFERENCES assets(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ---------------------------
-- ACTIVITY LOGS
-- ---------------------------
CREATE TABLE IF NOT EXISTS activity_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    action VARCHAR(255) NOT NULL,
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ---------------------------
-- SAMPLE DATA
-- ---------------------------
INSERT INTO assets (asset_code, asset_name, asset_category, serial_number, brand, model, cpu, ram, storage, os, department, building, floor, location, status) VALUES
('AST-0001','Dell OptiPlex 7090','Desktop PC','SN-DLP-001','Dell','OptiPlex 7090','Intel i7-11700','16GB DDR4','512GB NVMe','Windows 11 Pro','IT','HQ Tower','3','Room 301','Available'),
('AST-0002','HP ProBook 450','Laptop','SN-HP-002','HP','ProBook 450 G9','Intel i5-1235U','8GB DDR4','256GB SSD','Windows 11 Pro','Finance','HQ Tower','2','Room 210','Borrowed'),
('AST-0003','Epson L3250','Printer','SN-EP-003','Epson','EcoTank L3250',NULL,NULL,NULL,NULL,'Operations','HQ Tower','1','Reception','Maintenance');
