<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();

$page_title='User Form';
$active='users';

$id=(int)($_GET['id']??0);

$u=[
    'id'=>0,
    'fullname'=>'',
    'username'=>'',
    'email'=>'',
    'department'=>'',
    'role'=>'STAFF'
];

$error='';

if ($id) {
    $u = $conn->query("SELECT * FROM users WHERE id=$id")->fetch_assoc() ?: $u;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {

    $fn   = trim($_POST['fullname']);
    $un   = trim($_POST['username']);
    $em   = trim($_POST['email']);
    $dep  = trim($_POST['department']);
    $role = $_POST['role'];
    $pw   = $_POST['password'] ?? '';

    // CHECK DUPLICATE USERNAME
    if ($id) {

        $check = $conn->prepare("SELECT id FROM users WHERE username=? AND id!=?");
        $check->bind_param("si", $un, $id);

    } else {

        $check = $conn->prepare("SELECT id FROM users WHERE username=?");
        $check->bind_param("s", $un);

    }

    $check->execute();
    $res = $check->get_result();

    if ($res->num_rows > 0) {

        $error = "Username sudah digunakan.";

    } else {

        // UPDATE
        if ($id) {

            if ($pw !== '') {

                $h = password_hash($pw, PASSWORD_DEFAULT);

                $stmt = $conn->prepare("
                    UPDATE users
                    SET fullname=?, username=?, email=?, department=?, role=?, password=?
                    WHERE id=?
                ");

                $stmt->bind_param(
                    'ssssssi',
                    $fn,
                    $un,
                    $em,
                    $dep,
                    $role,
                    $h,
                    $id
                );

            } else {

                $stmt = $conn->prepare("
                    UPDATE users
                    SET fullname=?, username=?, email=?, department=?, role=?
                    WHERE id=?
                ");

                $stmt->bind_param(
                    'sssssi',
                    $fn,
                    $un,
                    $em,
                    $dep,
                    $role,
                    $id
                );
            }

            $stmt->execute();

        } else {

            // INSERT
            $h = password_hash($pw ?: 'password123', PASSWORD_DEFAULT);

            $stmt = $conn->prepare("
                INSERT INTO users
                (fullname, username, email, department, role, password)
                VALUES (?,?,?,?,?,?)
            ");

            $stmt->bind_param(
                'ssssss',
                $fn,
                $un,
                $em,
                $dep,
                $role,
                $h
            );

            $stmt->execute();
        }

        log_activity(
            $_SESSION['user_id'],
            $id ? 'USER_UPDATE' : 'USER_CREATE',
            $un
        );

        header('Location: list.php');
        exit;
    }
}

include __DIR__ . '/../includes/header.php';
?>

<?php if(!empty($error)): ?>
<div class="alert alert-danger">
    <i class="bi bi-exclamation-circle"></i>
    <?= e($error) ?>
</div>
<?php endif; ?>

<form method="post">

<div class="form-section">

    <div class="form-section-title">
        <i class="bi bi-person"></i>
        User Details
    </div>

    <div class="row g-3">

        <div class="col-md-6">
            <label class="form-label">Full Name *</label>
            <input
                class="form-control"
                name="fullname"
                value="<?= e($u['fullname']) ?>"
                required
            >
        </div>

        <div class="col-md-6">
            <label class="form-label">Username *</label>
            <input
                class="form-control"
                name="username"
                value="<?= e($u['username']) ?>"
                required
            >
        </div>

        <div class="col-md-6">
            <label class="form-label">Email</label>
            <input
                type="email"
                class="form-control"
                name="email"
                value="<?= e($u['email']) ?>"
            >
        </div>

        <div class="col-md-6">
            <label class="form-label">Department</label>
            <input
                class="form-control"
                name="department"
                value="<?= e($u['department']) ?>"
            >
        </div>

        <div class="col-md-6">

            <label class="form-label">Role *</label>

            <select name="role" class="form-select">

                <option value="ADMIN"
                    <?= $u['role']==='ADMIN'?'selected':'' ?>>
                    ADMIN
                </option>

                <option value="STAFF"
                    <?= $u['role']==='STAFF'?'selected':'' ?>>
                    STAFF
                </option>

            </select>

        </div>

        <div class="col-md-6">

            <label class="form-label">
                Password
                <?= $id
                    ? '<small class="text-muted">(leave blank to keep current)</small>'
                    : '*'
                ?>
            </label>

            <input
                type="password"
                class="form-control"
                name="password"
                <?= $id ? '' : 'required' ?>
            >

        </div>

    </div>

</div>

<button class="btn btn-gradient">
    <i class="bi bi-save"></i>
    Save
</button>

<a href="list.php" class="btn btn-light">
    Cancel
</a>

</form>

<?php include __DIR__ . '/../includes/footer.php'; ?>