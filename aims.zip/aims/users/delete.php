<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();
$id=(int)$_GET['id'];
if ($id != $_SESSION['user_id']) {
    $conn->query("DELETE FROM users WHERE id=$id");
    log_activity($_SESSION['user_id'],'USER_DELETE','Deleted user #'.$id);
}
header('Location: list.php'); exit;
