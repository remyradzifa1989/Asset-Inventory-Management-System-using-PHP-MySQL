<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();
$page_title = 'Users'; $active = 'users';

$rows       = $conn->query("SELECT * FROM users ORDER BY id DESC");
$total      = (int)$conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
$admin_cnt  = (int)$conn->query("SELECT COUNT(*) c FROM users WHERE role='ADMIN'")->fetch_assoc()['c'];
$staff_cnt  = (int)$conn->query("SELECT COUNT(*) c FROM users WHERE role='STAFF'")->fetch_assoc()['c'];

$data = [];
while ($u = $rows->fetch_assoc()) $data[] = $u;

include __DIR__ . '/../includes/header.php';
?>

<style>
*, *::before, *::after { box-sizing: border-box; }

.ul-wrap { display: flex; flex-direction: column; gap: 16px; padding-bottom: 32px; }

/* ── Page header ── */
.ul-page-header {
  display: flex; align-items: center; justify-content: space-between;
  flex-wrap: wrap; gap: 10px;
}
.ul-page-title {
  font-size: 18px; font-weight: 700;
  color: #0f172a; letter-spacing: -.3px;
  display: flex; align-items: center; gap: 8px;
}
.ul-page-title i { color: #6366f1; font-size: 20px; }

.ul-btn-new {
  display: inline-flex; align-items: center; gap: 7px;
  padding: 9px 18px;
  background: #6366f1; color: #fff;
  border-radius: 10px; font-size: 13.5px; font-weight: 500;
  text-decoration: none; border: none; cursor: pointer;
  transition: background .15s, transform .1s;
}
.ul-btn-new:hover  { background: #4f46e5; color: #fff; }
.ul-btn-new:active { transform: scale(.97); }

/* ── Stat cards ── */
.ul-stat-row { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; }
.ul-stat {
  background: #fff; border: 0.5px solid rgba(0,0,0,.08);
  border-radius: 12px; padding: 14px 16px;
  display: flex; align-items: center; gap: 12px;
}
.ul-stat-icon {
  width: 36px; height: 36px; border-radius: 9px;
  display: flex; align-items: center; justify-content: center;
  font-size: 17px; flex-shrink: 0;
}
.ul-stat-label { font-size: 10.5px; font-weight: 600; text-transform: uppercase; letter-spacing: .3px; color: #6b7280; }
.ul-stat-value { font-size: 22px; font-weight: 700; color: #0f172a; letter-spacing: -.4px; }
.si-total  .ul-stat-icon { background: #eff6ff; color: #2563eb; }
.si-admin  .ul-stat-icon { background: #f5f3ff; color: #7c3aed; }
.si-staff  .ul-stat-icon { background: #f0fdf4; color: #16a34a; }

/* ── Table card ── */
.ul-card {
  background: #fff; border: 0.5px solid rgba(0,0,0,.08);
  border-radius: 14px; overflow: hidden;
}
.ul-card-head {
  padding: 14px 18px;
  border-bottom: 0.5px solid #f1f5f9;
  display: flex; align-items: center; justify-content: space-between;
  flex-wrap: wrap; gap: 10px;
}
.ul-card-head-title {
  font-size: 11.5px; font-weight: 600;
  text-transform: uppercase; letter-spacing: .3px; color: #6b7280;
  display: flex; align-items: center; gap: 6px;
}

/* Search */
.ul-search-wrap { position: relative; }
.ul-search-wrap input {
  border: 0.5px solid #e2e8f0;
  border-radius: 9px;
  padding: 7px 12px 7px 34px;
  font-size: 13px; color: #374151;
  background: #f8fafc; outline: none;
  width: 220px;
  transition: border .15s, background .15s;
}
.ul-search-wrap input:focus { border-color: #6366f1; background: #fff; }
.ul-search-wrap i {
  position: absolute; left: 10px; top: 50%;
  transform: translateY(-50%); color: #94a3b8; font-size: 14px;
  pointer-events: none;
}

/* ── Table ── */
.ul-tbl { width: 100%; border-collapse: collapse; font-size: 13px; }
.ul-tbl th {
  text-align: left; padding: 10px 16px;
  font-size: 10.5px; font-weight: 600;
  color: #9ca3af; text-transform: uppercase; letter-spacing: .3px;
  border-bottom: 0.5px solid #f1f5f9;
  background: #fafafa;
  white-space: nowrap;
}
.ul-tbl td {
  padding: 12px 16px;
  border-bottom: 0.5px solid #f8fafc;
  color: #374151; vertical-align: middle;
}
.ul-tbl tr:last-child td { border-bottom: none; }
.ul-tbl tbody tr:hover td { background: #fafafa; }
.ul-tbl .col-id { font-family: ui-monospace, monospace; font-size: 11.5px; color: #94a3b8; }

/* Avatar */
.ul-avatar {
  width: 32px; height: 32px; border-radius: 50%;
  background: #6366f1; color: #fff;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 13px; font-weight: 600;
  flex-shrink: 0; margin-right: 9px;
  vertical-align: middle; text-transform: uppercase;
}
.ul-name { font-weight: 500; color: #0f172a; }
.ul-uname { font-size: 11.5px; color: #94a3b8; margin-top: 1px; }

/* Role badge */
.role-badge {
  display: inline-block; padding: 2px 10px;
  border-radius: 20px; font-size: 11px; font-weight: 600;
}
.role-admin { background: #f5f3ff; color: #6d28d9; }
.role-staff { background: #f0fdf4; color: #15803d; }

/* Action buttons */
.ul-actions { display: flex; gap: 6px; }
.ul-btn-action {
  display: inline-flex; align-items: center; justify-content: center;
  width: 32px; height: 32px; border-radius: 8px;
  font-size: 14px; border: 0.5px solid transparent;
  text-decoration: none; cursor: pointer;
  transition: background .15s, transform .1s;
}
.ul-btn-action:active { transform: scale(.92); }
.btn-edit   { background: #fffbeb; color: #b45309; border-color: #fde68a; }
.btn-edit:hover   { background: #fef3c7; }
.btn-delete { background: #fef2f2; color: #b91c1c; border-color: #fecaca; }
.btn-delete:hover { background: #fee2e2; }

/* Empty state */
.ul-empty { text-align: center; padding: 48px 20px; color: #94a3b8; font-size: 13px; }

/* No result (JS hide) */
.ul-no-result { display: none; }
.ul-no-result.show { display: table-row; }
</style>

<div class="ul-wrap">

  <!-- Page header -->
  <div class="ul-page-header">
    <div class="ul-page-title">
      <i class="bi bi-people-fill"></i> Users
    </div>
    <a href="form.php" class="ul-btn-new">
      <i class="bi bi-plus-lg"></i> New User
    </a>
  </div>

  <!-- Stat cards -->
  <div class="ul-stat-row">
    <div class="ul-stat si-total">
      <div class="ul-stat-icon"><i class="bi bi-people"></i></div>
      <div>
        <div class="ul-stat-label">Total Users</div>
        <div class="ul-stat-value"><?= $total ?></div>
      </div>
    </div>
    <div class="ul-stat si-admin">
      <div class="ul-stat-icon"><i class="bi bi-shield-check"></i></div>
      <div>
        <div class="ul-stat-label">Admins</div>
        <div class="ul-stat-value"><?= $admin_cnt ?></div>
      </div>
    </div>
    <div class="ul-stat si-staff">
      <div class="ul-stat-icon"><i class="bi bi-person-badge"></i></div>
      <div>
        <div class="ul-stat-label">Staff</div>
        <div class="ul-stat-value"><?= $staff_cnt ?></div>
      </div>
    </div>
  </div>

  <!-- Table card -->
  <div class="ul-card">
    <div class="ul-card-head">
      <span class="ul-card-head-title"><i class="bi bi-table"></i> All Users</span>
      <div class="ul-search-wrap">
        <i class="bi bi-search"></i>
        <input type="text" id="ulSearch" placeholder="Search name, username…">
      </div>
    </div>

    <?php if (empty($data)): ?>
      <div class="ul-empty">No users found. <a href="form.php">Add one now</a>.</div>
    <?php else: ?>
    <div style="overflow-x:auto">
      <table class="ul-tbl" id="ulTable">
        <thead>
          <tr>
            <th>No.</th>
            <th>User</th>
            <th>Email</th>
            <th>Department</th>
            <th>Role</th>
            <th>Created</th>
            <th>Actions</th>
          </tr>
        </thead>
       <tbody>

  <?php $no = 1; ?>

  <?php foreach ($data as $u): ?>
          <?php
            $initial = strtoupper(mb_substr($u['fullname'], 0, 1));
            // Generate consistent avatar colour from user id
            $hues    = ['#6366f1','#0891b2','#059669','#d97706','#dc2626','#7c3aed','#db2777'];
            $hue     = $hues[$u['id'] % count($hues)];
            $created = $u['created_at'] ? date('d M Y', strtotime($u['created_at'])) : '—';
          ?>
          <tr data-search="<?= strtolower(e($u['fullname']) . ' ' . e($u['username']) . ' ' . e($u['email']) . ' ' . e($u['department'])) ?>">
          <td class="col-id"><?= $no++ ?></td>
            <td>
              <span class="ul-avatar" style="background:<?= $hue ?>"><?= $initial ?></span>
              <span class="ul-name"><?= e($u['fullname']) ?></span>
              <div class="ul-uname" style="margin-left:41px">@<?= e($u['username']) ?></div>
            </td>
            <td><?= e($u['email'] ?: '—') ?></td>
            <td><?= e($u['department'] ?: '—') ?></td>
            <td>
              <span class="role-badge <?= $u['role'] === 'ADMIN' ? 'role-admin' : 'role-staff' ?>">
                <?= e($u['role']) ?>
              </span>
            </td>
            <td><?= $created ?></td>
            <td>
              <div class="ul-actions">
                <a class="ul-btn-action btn-edit" href="form.php?id=<?= $u['id'] ?>" title="Edit user">
                  <i class="bi bi-pencil"></i>
                </a>
                <?php if ((int)$u['id'] !== (int)$_SESSION['user_id']): ?>
                <a class="ul-btn-action btn-delete confirm-delete"
                   href="delete.php?id=<?= $u['id'] ?>"
                   title="Delete user"
                   data-name="<?= e($u['fullname']) ?>">
                  <i class="bi bi-trash"></i>
                </a>
                <?php else: ?>
                <span class="ul-btn-action" style="background:#f8fafc;color:#cbd5e1;cursor:default;border-color:#f1f5f9" title="Cannot delete yourself">
                  <i class="bi bi-trash"></i>
                </span>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
          <tr class="ul-no-result" id="ulNoResult">
            <td colspan="7" style="text-align:center;color:#94a3b8;padding:32px">No users match your search.</td>
          </tr>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

</div>

<script>
/* ── Live search ── */
(function () {
  var input   = document.getElementById('ulSearch');
  var noRes   = document.getElementById('ulNoResult');
  if (!input) return;

  input.addEventListener('input', function () {
    var q    = this.value.trim().toLowerCase();
    var rows = document.querySelectorAll('#ulTable tbody tr[data-search]');
    var vis  = 0;

    rows.forEach(function(row) {
      var match = !q || row.dataset.search.includes(q);
      row.style.display = match ? '' : 'none';
      if (match) vis++;
    });

    if (noRes) noRes.classList.toggle('show', vis === 0);
  });
})();

/* ── Delete confirmation ── */
document.querySelectorAll('.confirm-delete').forEach(function(el) {
  el.addEventListener('click', function(e) {
    var name = this.dataset.name || 'this user';
    if (!confirm('Delete ' + name + '?\n\nThis action cannot be undone.')) {
      e.preventDefault();
    }
  });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>