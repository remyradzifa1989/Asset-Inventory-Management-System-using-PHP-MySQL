<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$page_title='Asset Detail'; $active='assets';
$id = (int)($_GET['id'] ?? 0);
$stmt = $conn->prepare("SELECT * FROM assets WHERE id=?"); $stmt->bind_param('i',$id); $stmt->execute();
$a = $stmt->get_result()->fetch_assoc();
if (!$a) { die('Asset not found'); }
$files = $conn->query("SELECT * FROM asset_files WHERE asset_id=$id ORDER BY id DESC");

// Parse hardware JSON
$hw_label_map = [
    'motherboard' => 'Motherboard',
    'cpu'         => 'CPU',
    'ram'         => 'RAM',
    'storage'     => 'Storage',
    'gpu'         => 'GPU',
    'psu'         => 'PSU',
    'monitor'     => 'Monitor',
    'keyboard'    => 'Keyboard',
    'mouse'       => 'Mouse',
    'os'          => 'Operating System',
    'others'      => 'Others',
];
$hardware_rows = json_decode($a['hardware_spec'] ?? '[]', true) ?: [];

include __DIR__ . '/../includes/header.php';
$ok = flash_get('ok');
?>

<style>
.badge-status {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}
.badge-status.b-available    { background: #d1fae5; color: #065f46; }
.badge-status.b-used-by      { background: #ede9fe; color: #5b21b6; }
.badge-status.b-borrowed     { background: #fef3c7; color: #92400e; }
.badge-status.b-maintenance  { background: #dbeafe; color: #1e40af; }
.badge-status.b-damaged      { background: #fee2e2; color: #991b1b; }
.badge-status.b-disposed     { background: #f3f4f6; color: #6b7280; }
</style>

<?php if ($ok): ?><div class="alert alert-success"><?= e($ok) ?></div><?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h4 class="mb-0"><i class="bi bi-pc-display text-primary"></i> <?= e($a['asset_name']) ?> <small class="text-muted">· <?= e($a['asset_code']) ?></small></h4>
  <div class="no-print">
    <button onclick="window.print()" class="btn btn-secondary btn-sm"><i class="bi bi-printer"></i> Print</button>
    <?php if ($_SESSION['role']==='ADMIN'): ?>
      <a href="form.php?id=<?= $a['id'] ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil"></i> Edit</a>
    <?php endif; ?>
    <a href="list.php" class="btn btn-light btn-sm">Back</a>
  </div>
</div>

<div class="row g-3">
  <div class="col-lg-4">
    <div class="aims-card text-center">
      <?php if ($a['image']): ?>
        <img src="<?= UPLOAD_URL.e($a['image']) ?>" class="img-fluid rounded mb-3" style="max-height:240px">
      <?php else: ?>
        <div class="py-5"><i class="bi bi-pc-display" style="font-size:5rem;color:#cbd5e1"></i></div>
      <?php endif; ?>
      <span class="badge-status b-<?= strtolower(str_replace(' ', '-', $a['status'])) ?>"><?= e($a['status']) ?></span>
      <div class="mt-3 small text-muted">Created: <?= e($a['created_at']) ?></div>
    </div>
  </div>

  <div class="col-lg-8">

    <!-- Basic Information -->
    <div class="form-section">
      <div class="form-section-title"><i class="bi bi-info-circle"></i> Basic Information</div>
      <div class="detail-grid">
        <?php foreach ([
          'asset_code'=>'Asset Code','asset_name'=>'Name','asset_category'=>'Category','serial_number'=>'Serial No',
          'brand'=>'Brand','model'=>'Model','manufacturer_year'=>'Year','purchase_date'=>'Purchased','warranty_date'=>'Warranty'
        ] as $k=>$lbl): ?>
          <div class="detail-item"><div class="lbl"><?= $lbl ?></div><div class="val"><?= e($a[$k] ?: '-') ?></div></div>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- Hardware Specification -->
    <div class="form-section">
      <div class="form-section-title"><i class="bi bi-cpu"></i> Hardware Specification</div>
      <?php if (!empty($hardware_rows)): ?>
        <div class="detail-grid">
          <?php foreach ($hardware_rows as $hw):
            $lbl = $hw_label_map[$hw['type']] ?? ucfirst($hw['type']);
          ?>
            <div class="detail-item">
              <div class="lbl"><?= e($lbl) ?></div>
              <div class="val"><?= e($hw['value'] ?: '-') ?></div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <p class="text-muted mb-0"><i class="bi bi-dash-circle me-1"></i>Tiada spesifikasi hardware direkodkan.</p>
      <?php endif; ?>
    </div>

    <!-- Location & User -->
    <div class="form-section">
      <div class="form-section-title"><i class="bi bi-geo-alt"></i> User & Branch</div>
      <div class="detail-grid">
        <?php foreach (['use_by'=>'Used By','department'=>'Department','building'=>'Branch','floor'=>'Floor','location'=>'Building'] as $k=>$lbl): ?>
          <div class="detail-item"><div class="lbl"><?= $lbl ?></div><div class="val"><?= e($a[$k] ?: '-') ?></div></div>
        <?php endforeach; ?>
      </div>
      <?php if ($a['remarks']): ?>
        <div class="mt-3 p-3 bg-light rounded"><strong>Remarks:</strong> <?= e($a['remarks']) ?></div>
      <?php endif; ?>
    </div>

    <!-- Attachments -->
<div class="form-section">
  <div class="form-section-title"><i class="bi bi-paperclip"></i> Attachments</div>
  <?php if ($files->num_rows): ?>
    <div class="row g-2">
    <?php while($f=$files->fetch_assoc()):
      $isImg = in_array(strtolower($f['file_type']),['jpg','jpeg','png']); ?>
      <div class="col-md-3 col-6">
        <div class="aims-card p-2 text-center">
          <?php if ($isImg): ?>
            <a href="<?= UPLOAD_URL.e($f['file_name']) ?>" target="_blank">
              <img src="<?= UPLOAD_URL.e($f['file_name']) ?>" class="img-fluid rounded" style="height:90px;object-fit:cover;width:100%">
            </a>
          <?php else: ?>
            <div style="height:90px" class="d-grid place-items-center">
              <i class="bi bi-file-earmark-text" style="font-size:3rem;color:#94a3b8"></i>
            </div>
          <?php endif; ?>
          <div class="small text-truncate mt-2" title="<?= e($f['original_name']) ?>"><?= e($f['original_name']) ?></div>
          <div class="d-flex gap-1 mt-2">
            <!-- View button - semua boleh tengok -->
            <a class="btn btn-sm btn-outline-info flex-fill" href="<?= UPLOAD_URL.e($f['file_name']) ?>" target="_blank">
              <i class="bi bi-eye"></i>
            </a>
            <!-- Download button - admin sahaja -->
            <?php if ($_SESSION['role']==='ADMIN'): ?>
              <a class="btn btn-sm btn-outline-primary flex-fill" href="<?= UPLOAD_URL.e($f['file_name']) ?>" download>
                <i class="bi bi-download"></i>
              </a>
              <a class="btn btn-sm btn-outline-danger confirm-delete" href="delete_file.php?id=<?= $f['id'] ?>&asset=<?= $id ?>">
                <i class="bi bi-trash"></i>
              </a>
            <?php endif; ?>
          </div>
        </div>
      </div>
    <?php endwhile; ?>
    </div>
  <?php else: ?>
    <p class="text-muted mb-0">No attachments uploaded.</p>
  <?php endif; ?>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>