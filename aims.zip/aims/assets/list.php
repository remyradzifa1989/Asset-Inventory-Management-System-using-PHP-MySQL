<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$page_title='Assets'; $active='assets';

$where = []; $params = []; $types = '';
if (!empty($_GET['category'])) { $where[]='asset_category=?'; $params[]=$_GET['category']; $types.='s'; }
if (!empty($_GET['department'])) { $where[]='department=?'; $params[]=$_GET['department']; $types.='s'; }
if (!empty($_GET['status']))    { $where[]='status=?'; $params[]=$_GET['status']; $types.='s'; }
if (!empty($_GET['building']))  { $where[]='building=?'; $params[]=$_GET['building']; $types.='s'; }
if (!empty($_GET['q'])) {
    $q = '%'.$_GET['q'].'%';
    $where[]='(asset_code LIKE ? OR asset_name LIKE ? OR serial_number LIKE ? OR use_by LIKE ?)';
    array_push($params,$q,$q,$q,$q); $types.='ssss';
}
$sql = "SELECT * FROM assets" . ($where ? ' WHERE '.implode(' AND ',$where) : '') . " ORDER BY id DESC";
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute(); $rows = $stmt->get_result();

$cats = $conn->query("SELECT DISTINCT asset_category FROM assets WHERE asset_category<>'' ORDER BY 1");
$deps = $conn->query("SELECT DISTINCT department FROM assets WHERE department<>'' ORDER BY 1");
$blds = $conn->query("SELECT DISTINCT building FROM assets WHERE building<>'' ORDER BY 1");

include __DIR__ . '/../includes/header.php';
?>

<style>
.badge-status {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
}
.badge-status.b-available    { background: #d1fae5; color: #065f46; }
.badge-status.b-used-by      { background: #ede9fe; color: #5b21b6; }
.badge-status.b-borrowed     { background: #fef3c7; color: #92400e; }
.badge-status.b-maintenance  { background: #dbeafe; color: #1e40af; }
.badge-status.b-damaged      { background: #fee2e2; color: #991b1b; }
.badge-status.b-disposed     { background: #f3f4f6; color: #6b7280; }
</style>

<div class="aims-card mb-3">
  <form class="row g-2 align-items-end" method="get">
    <div class="col-md-3"><label class="form-label small">Search</label>
      <input class="form-control form-control-sm" name="q" value="<?= e($_GET['q']??'') ?>" placeholder="Use By, Asset Code and Asset Name">
    </div>
    <div class="col-md-2"><label class="form-label small">Category</label>
      <select class="form-select form-select-sm" name="category"><option value="">All</option>
      <?php while($c=$cats->fetch_assoc()): ?><option <?= ($_GET['category']??'')===$c['asset_category']?'selected':'' ?>><?= e($c['asset_category']) ?></option><?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-2"><label class="form-label small">Department</label>
      <select class="form-select form-select-sm" name="department"><option value="">All</option>
      <?php while($d=$deps->fetch_assoc()): ?><option <?= ($_GET['department']??'')===$d['department']?'selected':'' ?>><?= e($d['department']) ?></option><?php endwhile; ?>
      </select>
    </div>
    
    <div class="col-md-2"><label class="form-label small">Branch</label>
      <select class="form-select form-select-sm" name="building"><option value="">All</option>
      <?php while($b=$blds->fetch_assoc()): ?><option <?= ($_GET['building']??'')===$b['building']?'selected':'' ?>><?= e($b['building']) ?></option><?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-2"><label class="form-label small">Status</label>
      <select class="form-select form-select-sm" name="status"><option value="">All</option>
      <?php foreach(['Available','Used By','Borrowed','Maintenance','Damaged','Disposed'] as $s): ?>
        <option value="<?= $s ?>" <?= ($_GET['status']??'')===$s?'selected':'' ?>><?= $s ?></option>
      <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-1 d-grid"><button class="btn btn-gradient btn-sm">Filter</button></div>
  </form>
</div>

<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <a href="export.php?type=excel<?= '&'.http_build_query($_GET) ?>" class="btn btn-success btn-sm"><i class="bi bi-file-earmark-excel"></i> Excel</a>
    <a href="export.php?type=pdf<?= '&'.http_build_query($_GET) ?>" class="btn btn-danger btn-sm"><i class="bi bi-file-earmark-pdf"></i> PDF</a>
    <!-- <button onclick="window.print()" class="btn btn-secondary btn-sm"><i class="bi bi-printer"></i> Print</button> -->
  </div>
  <?php if ($_SESSION['role']==='ADMIN'): ?>
  <a href="form.php" class="btn btn-gradient"><i class="bi bi-plus-lg"></i> New Asset</a>
  <?php endif; ?>
</div>

<div class="aims-table p-3">
<table class="table aims-dt align-middle w-100">
  <thead><tr>
    <th style="width:50px">No.</th><th>Asset Code</th><th>Use By</th><th>Asset Name</th><th>Category</th><th>Department</th><th>Branch</th><th>Status</th><th class="no-print">Actions</th>
  </tr></thead>
  <tbody>
  <?php $no = 1; while($a=$rows->fetch_assoc()): ?>
    <tr>
      <td class="text-muted text-center"><?= $no++ ?></td>
      <td><strong><?= e($a['asset_code']) ?></strong></td>
      <td><strong><?= e($a['use_by']) ?></strong></td>
      <td><?= e($a['asset_name']) ?><br><small class="text-muted"><?= e($a['brand']) ?> <?= e($a['model']) ?></small></td>
      <td><?= e($a['asset_category']) ?></td>
      <td><?= e($a['department']) ?></td>
      <td><?= e(trim(($a['building']?:'').' '.($a['floor']?'· Floor '.$a['floor']:''))) ?></td>
      <td><span class="badge-status b-<?= strtolower(str_replace(' ', '-', $a['status'])) ?>"><?= e($a['status']) ?></span></td>
      <td class="no-print">
        <a href="view.php?id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-primary"><i class="bi bi-eye"></i></a>
        <?php if ($_SESSION['role']==='ADMIN'): ?>
        <a href="form.php?id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
        <a href="delete.php?id=<?= $a['id'] ?>" class="btn btn-sm btn-outline-danger confirm-delete"><i class="bi bi-trash"></i></a>
        <?php endif; ?>
      </td>
    </tr>
  <?php endwhile; ?>
  </tbody>
</table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>