<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();
$id=(int)($_GET['id']??0); $aid=(int)($_GET['asset']??0);
if ($id) {
    $r = $conn->query("SELECT file_name FROM asset_files WHERE id=$id")->fetch_assoc();
    if ($r) @unlink(UPLOAD_DIR.$r['file_name']);
    $conn->query("DELETE FROM asset_files WHERE id=$id");
}
header('Location: view.php?id='.$aid); exit;
