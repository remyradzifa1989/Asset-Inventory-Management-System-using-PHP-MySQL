<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();
$id=(int)($_GET['id']??0);
if ($id) {
    // delete attachment files
    $r = $conn->query("SELECT file_name FROM asset_files WHERE asset_id=$id");
    while ($f = $r->fetch_assoc()) @unlink(UPLOAD_DIR.$f['file_name']);
    $a = $conn->query("SELECT image FROM assets WHERE id=$id")->fetch_assoc();
    if (!empty($a['image'])) @unlink(UPLOAD_DIR.$a['image']);
    $conn->query("DELETE FROM assets WHERE id=$id");
    log_activity($_SESSION['user_id'],'ASSET_DELETE','Deleted asset #'.$id);
}
header('Location: list.php'); exit;
