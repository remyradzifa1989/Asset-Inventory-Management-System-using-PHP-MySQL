<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$type = $_GET['type'] ?? 'excel';

// ── Filter ────────────────────────────────────────────────────────────────
$where=[]; $params=[]; $types='';
if (!empty($_GET['category']))   { $where[]='asset_category=?'; $params[]=$_GET['category']; $types.='s'; }
if (!empty($_GET['department'])) { $where[]='department=?'; $params[]=$_GET['department']; $types.='s'; }
if (!empty($_GET['status']))     { $where[]='status=?'; $params[]=$_GET['status']; $types.='s'; }
if (!empty($_GET['building']))   { $where[]='building=?'; $params[]=$_GET['building']; $types.='s'; }
if (!empty($_GET['q'])) {
    $q='%'.$_GET['q'].'%';
    $where[]='(asset_code LIKE ? OR asset_name LIKE ? OR serial_number LIKE ? OR use_by LIKE ?)';
    array_push($params,$q,$q,$q,$q); $types.='ssss';
}
$sql = "SELECT asset_code, asset_name, asset_category, brand, model, serial_number, use_by, department, building, floor, location, status
        FROM assets" . ($where ? ' WHERE '.implode(' AND ',$where) : '') . " ORDER BY id DESC";
$stmt=$conn->prepare($sql);
if ($params) $stmt->bind_param($types,...$params);
$stmt->execute();
$rows=$stmt->get_result();

// ── Active filters label ──────────────────────────────────────────────────
$filter_labels = [];
if (!empty($_GET['q']))          $filter_labels[] = 'Search: '.$_GET['q'];
if (!empty($_GET['category']))   $filter_labels[] = 'Category: '.$_GET['category'];
if (!empty($_GET['department'])) $filter_labels[] = 'Dept: '.$_GET['department'];
if (!empty($_GET['status']))     $filter_labels[] = 'Status: '.$_GET['status'];
if (!empty($_GET['building']))   $filter_labels[] = 'Building: '.$_GET['building'];
$filter_text = $filter_labels ? implode('   ·   ', $filter_labels) : 'All Records';

// ── Excel export ──────────────────────────────────────────────────────────
if ($type === 'excel') {
    header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
    header('Content-Disposition: attachment; filename="Asset_Inventory_'.date('d-m-Y').'.xls"');
    echo "\xEF\xBB\xBF";
    ?>
    <html xmlns:o="urn:schemas-microsoft-com:office:office"
          xmlns:x="urn:schemas-microsoft-com:office:excel"
          xmlns="http://www.w3.org/TR/REC-html40">
    <head><meta charset="UTF-8">
    <!--[if gte mso 9]><xml>
    <x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>
    <x:Name>Asset Inventory</x:Name>
    <x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions>
    </x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook>
    </xml><![endif]-->
    <style>
        body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; }
        .title-row td {
            background: #1E3A5F; color: #FFFFFF;
            font-size: 14pt; font-weight: bold;
            padding: 10px 14px; border: none;
        }
        .meta-row td {
            background: #EBF2FC; color: #4A6A8A;
            font-size: 9pt; font-style: italic;
            padding: 4px 14px; border: none;
        }
        .filter-row td {
            background: #D6E8FA; color: #1E3A5F;
            font-size: 9pt; padding: 4px 14px; border: none;
        }
        .spacer td { background: #FFFFFF; padding: 4px; border: none; }
        .header-row th {
            background: #1E3A5F; color: #FFFFFF;
            font-weight: bold; font-size: 10pt;
            padding: 8px 10px; text-align: center;
            border: 1px solid #4A7AAF;
        }
        .data-row td {
            padding: 6px 10px; font-size: 10pt;
            border: 1px solid #D0DFF0;
            vertical-align: middle;
        }
        .data-row.even td { background: #F5F9FF; }
        .data-row.odd  td { background: #FFFFFF; }
        .status-available { background: #D1FAE5 !important; color: #065F46; font-weight: bold; text-align: center; }
        .status-borrowed  { background: #FEF3C7 !important; color: #92400E; font-weight: bold; text-align: center; }
        .status-maintenance { background: #FEE2E2 !important; color: #991B1B; font-weight: bold; text-align: center; }
        .status-other { background: #F3F4F6 !important; color: #374151; font-weight: bold; text-align: center; }
        .total-row td {
            background: #EBF2FC; color: #1E3A5F;
            font-weight: bold; font-size: 10pt;
            padding: 6px 10px; border-top: 2px solid #1E3A5F;
        }
        .no-col { text-align: center; }
    </style>
    </head><body>
    <table style="width:100%; border-collapse:collapse;">
        <!-- Title -->
        <tr class="title-row">
            <td colspan="11">&#128196; &nbsp; ASSET INVENTORY REPORT</td>
        </tr>
        <!-- Meta -->
        <tr class="meta-row">
            <td colspan="11">Generated on <?= date('d F Y, h:i A') ?> &nbsp;&nbsp;|&nbsp;&nbsp; System: AIMS Asset Management</td>
        </tr>
        <!-- Filter -->
        <tr class="filter-row">
            <td colspan="11">&#128269; &nbsp; Filter Applied: <?= htmlspecialchars($filter_text) ?></td>
        </tr>
        <!-- Spacer -->
        <tr class="spacer"><td colspan="11"></td></tr>
        <!-- Header -->
        <tr class="header-row">
            <th>No.</th><th>Asset Code</th><th>Asset Name</th><th>Category</th>
            <th>Brand</th><th>Model</th><th>Serial Number</th><th>Used By</th>
            <th>Department</th><th>Location</th><th>Status</th>
        </tr>
        <?php
        $no = 1; $total = 0;
        while ($r = $rows->fetch_assoc()):
            $branch = trim(($r['building'] ?: '') . ' ' . ($r['floor'] ? 'F'.$r['floor'] : ''));
            if ($r['location']) $branch = $branch ? $branch.' · '.$r['location'] : $r['location'];
            $rowClass = ($no % 2 === 0) ? 'even' : 'odd';
            $statusClass = match(strtolower($r['status'] ?? '')) {
                'available'   => 'status-available',
                'borrowed'    => 'status-borrowed',
                'maintenance' => 'status-maintenance',
                default       => 'status-other',
            };
            $total++; 
        ?>
        <tr class="data-row <?= $rowClass ?>">
            <td class="no-col"><?= $no++ ?></td>
            <td><b><?= e($r['asset_code']) ?></b></td>
            <td><?= e($r['asset_name']) ?></td>
            <td><?= e($r['asset_category']) ?></td>
            <td><?= e($r['brand']) ?></td>
            <td><?= e($r['model']) ?></td>
            <td><?= e($r['serial_number']) ?></td>
            <td><?= e($r['use_by']) ?></td>
            <td><?= e($r['department']) ?></td>
            <td><?= e($branch) ?></td>
            <td class="<?= $statusClass ?>"><?= e($r['status']) ?></td>
        </tr>
        <?php endwhile; ?>
        <!-- Total -->
        <tr class="total-row">
            <td colspan="10">Total Records</td>
            <td style="text-align:center"><?= $total ?></td>
        </tr>
    </table>
    </body></html>
    <?php
    exit;
}

// ── PDF (HTML print) ──────────────────────────────────────────────────────
$all = $rows->fetch_all(MYSQLI_ASSOC);
$total = count($all);
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<title>Asset Inventory Report</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=DM+Mono:wght@400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --navy:   #1E3A5F;
    --blue:   #2563EB;
    --sky:    #EBF4FF;
    --border: #D0DFF0;
    --text:   #0F172A;
    --muted:  #64748B;
  }

  body {
    font-family: 'DM Sans', sans-serif;
    background: #F8FAFC;
    color: var(--text);
    padding: 32px;
    font-size: 12px;
  }

  /* ── Header block ── */
  .report-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 24px;
    padding-bottom: 20px;
    border-bottom: 3px solid var(--navy);
  }
  .report-logo {
    display: flex;
    align-items: center;
    gap: 14px;
  }
  .logo-icon {
    width: 48px; height: 48px;
    background: var(--navy);
    border-radius: 12px;
    display: flex; align-items: center; justify-content: center;
    font-size: 22px; color: white;
  }
  .report-title { font-size: 22px; font-weight: 700; color: var(--navy); line-height: 1.1; }
  .report-sub   { font-size: 11px; color: var(--muted); margin-top: 3px; }
  .report-meta  { text-align: right; font-size: 11px; color: var(--muted); line-height: 1.8; }
  .report-meta strong { color: var(--navy); }

  /* ── Filter pill bar ── */
  .filter-bar {
    background: var(--sky);
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 8px 14px;
    margin-bottom: 20px;
    font-size: 11px;
    color: var(--navy);
    display: flex;
    align-items: center;
    gap: 8px;
  }
  .filter-bar .label { font-weight: 600; }
  .filter-pill {
    background: white;
    border: 1px solid var(--border);
    border-radius: 20px;
    padding: 2px 10px;
    font-size: 10.5px;
    color: var(--navy);
  }

  /* ── Stats row ── */
  .stats-row {
    display: flex;
    gap: 12px;
    margin-bottom: 20px;
  }
  .stat-card {
    flex: 1;
    background: white;
    border: 1px solid var(--border);
    border-radius: 10px;
    padding: 10px 14px;
    text-align: center;
  }
  .stat-num  { font-size: 20px; font-weight: 700; color: var(--navy); }
  .stat-lbl  { font-size: 10px; color: var(--muted); margin-top: 2px; }

  /* ── Table ── */
  table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 1px 4px rgba(0,0,0,.08);
  }
  thead tr {
    background: var(--navy);
    color: white;
  }
  thead th {
    padding: 9px 8px;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: .5px;
    text-align: left;
    white-space: nowrap;
  }
  thead th:first-child { text-align: center; width: 36px; }
  tbody tr:nth-child(even) { background: #F5F9FF; }
  tbody tr:hover           { background: #EBF4FF; }
  tbody td {
    padding: 7px 8px;
    border-bottom: 1px solid var(--border);
    font-size: 11px;
    vertical-align: middle;
  }
  tbody td:first-child { text-align: center; color: var(--muted); font-family: 'DM Mono', monospace; }
  .asset-code { font-family: 'DM Mono', monospace; font-weight: 500; color: var(--blue); font-size: 10.5px; }

  /* Status badges */
  .badge {
    display: inline-block;
    padding: 2px 9px;
    border-radius: 20px;
    font-size: 10px;
    font-weight: 600;
    white-space: nowrap;
  }
  .b-available    { background:#D1FAE5; color:#065F46; }
  .b-borrowed     { background:#FEF3C7; color:#92400E; }
  .b-maintenance  { background:#FEE2E2; color:#991B1B; }
  .b-other        { background:#F1F5F9; color:#475569; }

  /* ── Footer row ── */
  tfoot td {
    background: var(--sky);
    font-weight: 600;
    font-size: 11px;
    color: var(--navy);
    padding: 8px;
    border-top: 2px solid var(--navy);
  }

  /* ── Print button ── */
  .print-bar {
    display: flex;
    justify-content: flex-end;
    gap: 10px;
    margin-bottom: 20px;
  }
  .btn-print {
    background: var(--navy);
    color: white;
    border: none;
    padding: 8px 20px;
    border-radius: 8px;
    font-size: 12px;
    font-family: 'DM Sans', sans-serif;
    font-weight: 600;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 6px;
  }
  .btn-close {
    background: white;
    color: var(--navy);
    border: 1px solid var(--border);
    padding: 8px 16px;
    border-radius: 8px;
    font-size: 12px;
    font-family: 'DM Sans', sans-serif;
    font-weight: 500;
    cursor: pointer;
  }

  /* ── Footer ── */
  .report-footer {
    margin-top: 20px;
    padding-top: 12px;
    border-top: 1px solid var(--border);
    display: flex;
    justify-content: space-between;
    font-size: 10px;
    color: var(--muted);
  }

  @media print {
    body { background: white; padding: 16px; }
    .no-print { display: none !important; }
    table { box-shadow: none; }
    .stats-row { break-inside: avoid; }
  }
</style>
</head>
<body>

<!-- Print bar -->
<div class="print-bar no-print">
  <button class="btn-close" onclick="window.close()">✕ Close</button>
  <button class="btn-print" onclick="window.print()">🖨️ &nbsp;Print / Save as PDF</button>
</div>

<!-- Report header -->
<div class="report-header">
  <div class="report-logo">
    <div class="logo-icon">📦</div>
    <div>
      <div class="report-title">Asset Inventory Report</div>
      <div class="report-sub">AIMS — Asset Inventory Management System</div>
    </div>
  </div>
  <div class="report-meta">
    <div>Generated: <strong><?= date('d F Y, h:i A') ?></strong></div>
    <div>Prepared by: <strong><?= e($_SESSION['fullname'] ?? 'System') ?></strong></div>
    <div>Total Records: <strong><?= $total ?></strong></div>
  </div>
</div>

<!-- Filter bar -->
<div class="filter-bar">
  <span class="label">🔍 Filter:</span>
  <?php if ($filter_labels): ?>
    <?php foreach ($filter_labels as $fl): ?>
      <span class="filter-pill"><?= htmlspecialchars($fl) ?></span>
    <?php endforeach; ?>
  <?php else: ?>
    <span class="filter-pill">All Records</span>
  <?php endif; ?>
</div>

<!-- Stats -->
<?php
$countStatus = [];
foreach ($all as $r) {
    $s = $r['status'] ?? 'Unknown';
    $countStatus[$s] = ($countStatus[$s] ?? 0) + 1;
}
$available   = $countStatus['Available']   ?? 0;
$borrowed    = $countStatus['Borrowed']    ?? 0;
$maintenance = $countStatus['Maintenance'] ?? 0;
$other       = $total - $available - $borrowed - $maintenance;
?>
<div class="stats-row no-print">
  <div class="stat-card">
    <div class="stat-num"><?= $total ?></div>
    <div class="stat-lbl">Total Assets</div>
  </div>
  <div class="stat-card">
    <div class="stat-num" style="color:#065F46"><?= $available ?></div>
    <div class="stat-lbl">Available</div>
  </div>
  <div class="stat-card">
    <div class="stat-num" style="color:#92400E"><?= $borrowed ?></div>
    <div class="stat-lbl">Borrowed</div>
  </div>
  <div class="stat-card">
    <div class="stat-num" style="color:#991B1B"><?= $maintenance ?></div>
    <div class="stat-lbl">Maintenance</div>
  </div>
  <?php if ($other > 0): ?>
  <div class="stat-card">
    <div class="stat-num" style="color:#475569"><?= $other ?></div>
    <div class="stat-lbl">Others</div>
  </div>
  <?php endif; ?>
</div>

<!-- Table -->
<table>
  <thead>
    <tr>
      <th>No.</th>
      <th>Asset Code</th>
      <th>Asset Name</th>
      <th>Category</th>
      <th>Brand / Model</th>
      <th>Serial Number</th>
      <th>Used By</th>
      <th>Department</th>
      <th>Location</th>
      <th>Status</th>
    </tr>
  </thead>
  <tbody>
  <?php $no = 1; foreach ($all as $r):
    $branch = trim(($r['building'] ?: '') . ' ' . ($r['floor'] ? 'F'.$r['floor'] : ''));
    if ($r['location']) $branch = $branch ? $branch.' · '.$r['location'] : $r['location'];
    $badgeClass = match(strtolower($r['status'] ?? '')) {
      'available'   => 'b-available',
      'borrowed'    => 'b-borrowed',
      'maintenance' => 'b-maintenance',
      default       => 'b-other',
    };
  ?>
    <tr>
      <td><?= $no++ ?></td>
      <td><span class="asset-code"><?= e($r['asset_code']) ?></span></td>
      <td><?= e($r['asset_name']) ?></td>
      <td><?= e($r['asset_category']) ?></td>
      <td><?= e($r['brand']) ?><?= $r['model'] ? '<br><span style="color:var(--muted);font-size:10px">'.e($r['model']).'</span>' : '' ?></td>
      <td style="font-family:'DM Mono',monospace;font-size:10.5px"><?= e($r['serial_number']) ?></td>
      <td><?= e($r['use_by']) ?></td>
      <td><?= e($r['department']) ?></td>
      <td><?= e($branch) ?></td>
      <td><span class="badge <?= $badgeClass ?>"><?= e($r['status']) ?></span></td>
    </tr>
  <?php endforeach; ?>
  </tbody>
  <tfoot>
    <tr>
      <td colspan="9" style="text-align:right">Total Records:</td>
      <td style="text-align:center"><?= $total ?></td>
    </tr>
  </tfoot>
</table>

<!-- Footer -->
<div class="report-footer">
  <span>AIMS — Asset Inventory Management System</span>
  <span>Printed: <?= date('d M Y, h:i A') ?></span>
</div>

</body>
</html>