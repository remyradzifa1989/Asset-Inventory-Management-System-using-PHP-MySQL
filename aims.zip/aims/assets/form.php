<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();
$page_title='Asset Form'; $active='assets';

$id = (int)($_GET['id'] ?? 0);
$asset = ['id'=>0,'asset_code'=>'AST-'.str_pad((int)$conn->query("SELECT IFNULL(MAX(id),0)+1 n FROM assets")->fetch_assoc()['n'],4,'0',STR_PAD_LEFT)];
$fields = ['asset_code','asset_name','asset_category','serial_number','brand','model','hardware_spec','use_by','department','building','floor','location','manufacturer_year','purchase_date','warranty_date','status','remarks','image'];
foreach ($fields as $f) $asset[$f] = '';
$asset['status']='Available';
$asset['hardware_spec']='[]';

if ($id) {
    $stmt = $conn->prepare("SELECT * FROM assets WHERE id=?");
    $stmt->bind_param('i',$id); $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    if ($row) $asset = $row;
}

$hardware_rows = json_decode($asset['hardware_spec'] ?? '[]', true) ?: [];

/* ── Branch options ── */
$branches = [
    'HQ - KELANA JAYA',
    'ALOR SETAR, KEDAH',
    'KOTA BHARU, KELANTAN',
    'KUCHING, SARAWAK',
    'TAMPOI, JOHOR BAHRU',
    'BANDAR BARU BANGI, SELANGOR',
    'BANDAR BARU SRI PERMAISURI, KUALA LUMPUR',
    'IPOH, PERAK',
    'KELANA JAYA, SELANGOR',
];

if ($_SERVER['REQUEST_METHOD']==='POST') {

    $hw_input = $_POST['hardware'] ?? [];
    $hw_clean = [];
    foreach ($hw_input as $row) {
        $type  = trim($row['type']  ?? '');
        $value = trim($row['value'] ?? '');
        if ($type !== '' && $value !== '') {
            $hw_clean[] = ['type' => $type, 'value' => $value];
        }
    }
    $hardware_json = json_encode($hw_clean);

    $data = [];
    $simple_fields = ['asset_code','asset_name','asset_category','serial_number','brand','model',
                      'use_by','department','building','floor','location','manufacturer_year',
                      'purchase_date','warranty_date','status','remarks'];
    foreach ($simple_fields as $f) $data[$f] = trim($_POST[$f] ?? '');
    foreach (['purchase_date','warranty_date'] as $d) if ($data[$d]==='') $data[$d]=null;
    $data['hardware_spec'] = $hardware_json;

    if (!empty($_FILES['image']['name'])) {
        $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
        $newname = 'asset_' . time() . '_' . rand(1000,9999) . '.' . $ext;
        if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);
        if (move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . $newname)) {
            $data['image'] = $newname;
        } else {
            $data['image'] = $id ? $conn->query("SELECT image FROM assets WHERE id=$id")->fetch_assoc()['image'] ?? '' : '';
        }
    } else {
        $data['image'] = $id ? $conn->query("SELECT image FROM assets WHERE id=$id")->fetch_assoc()['image'] ?? '' : '';
    }

    // =====================================================
    // LANGKAH 3 — Check duplicate asset_code sebelum save
    // =====================================================
    $check_stmt = $conn->prepare("SELECT id FROM assets WHERE asset_code = ? AND id != ?");
    $check_id   = $id ?: 0;
    $check_stmt->bind_param('si', $data['asset_code'], $check_id);
    $check_stmt->execute();
    $check_stmt->store_result();

    if ($check_stmt->num_rows > 0) {
        flash_set('err', 'Asset Code "' . $data['asset_code'] . '" sudah wujud. Sila guna kod lain.');
        header('Location: form.php' . ($id ? '?id='.$id : ''));
        exit;
    }
    $check_stmt->close();
    // =====================================================

    $all_fields = array_keys($data);

    if ($id) {
        // LANGKAH 2 — UPDATE dengan try-catch
        $set   = implode(',', array_map(fn($f)=>"$f=?", $all_fields));
        $sql   = "UPDATE assets SET $set WHERE id=?";
        $types = str_repeat('s', count($all_fields)).'i';
        $vals  = array_values($data);
        $vals[]= $id;
        $stmt  = $conn->prepare($sql);
        $stmt->bind_param($types, ...$vals);
        try {
            $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                flash_set('err', 'Asset Code sudah wujud. Sila guna kod lain.');
                header('Location: form.php?id='.$id);
                exit;
            }
            throw $e;
        }
        $aid = $id;
        $msg = 'Asset updated successfully';
        log_activity($_SESSION['user_id'],'ASSET_UPDATE','Updated asset #'.$id);
    } else {
        $cols  = implode(',', $all_fields);
        $marks = implode(',', array_fill(0, count($all_fields), '?'));
        $stmt  = $conn->prepare("INSERT INTO assets ($cols) VALUES ($marks)");
        $stmt->bind_param(str_repeat('s', count($all_fields)), ...array_values($data));
        try {
            $stmt->execute();
        } catch (mysqli_sql_exception $e) {
            if ($e->getCode() == 1062) {
                flash_set('err', 'Asset Code sudah wujud. Sila guna kod lain.');
                header('Location: form.php' . ($id ? '?id='.$id : ''));
                exit;
            }
            throw $e;
        }
        $aid = $stmt->insert_id;
        $msg = 'Asset created successfully';
        log_activity($_SESSION['user_id'],'ASSET_CREATE','Created asset #'.$aid);
    }

    if (!empty($_FILES['files']['name'][0])) {
        if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0775, true);
        $allowed=['jpg','jpeg','png','pdf','docx','xlsx','doc','xls'];
        foreach ($_FILES['files']['name'] as $i => $name) {
            if (!$name) continue;
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, $allowed)) continue;
            $newname = 'att_' . time() . '_' . $i . '_' . rand(1000,9999) . '.' . $ext;
            if (move_uploaded_file($_FILES['files']['tmp_name'][$i], UPLOAD_DIR . $newname)) {
                $stmt2 = $conn->prepare("INSERT INTO asset_files (asset_id,file_name,original_name,file_type) VALUES (?,?,?,?)");
                $stmt2->bind_param('isss', $aid, $newname, $name, $ext);
                $stmt2->execute();
            }
        }
    }

    flash_set('ok', $msg);
    header('Location: view.php?id='.$aid); exit;
}

include __DIR__ . '/../includes/header.php';
?>

<style>
.hw-row {
    display: grid;
    grid-template-columns: 180px 1fr auto;
    gap: 10px;
    align-items: end;
    background: #f8f9fa;
    border: 1px solid #e9ecef;
    border-radius: 8px;
    padding: 10px 12px;
    margin-bottom: 8px;
    transition: border-color .2s;
}
.hw-row:hover { border-color: #ced4da; }
.hw-row label { font-size: 12px; color: #6c757d; margin-bottom: 4px; display: block; font-weight: 500; }
.hw-row select,
.hw-row input[type="text"] { width: 100%; box-sizing: border-box; }
.btn-hw-remove {
    border: 1px solid #dee2e6;
    background: transparent;
    color: #dc3545;
    border-radius: 6px;
    padding: 6px 10px;
    cursor: pointer;
    font-size: 14px;
    line-height: 1;
    transition: background .15s, border-color .15s;
    white-space: nowrap;
    align-self: flex-end;
}
.btn-hw-remove:hover { background: #fff5f5; border-color: #dc3545; }
.btn-hw-add {
    border: 1px dashed #adb5bd;
    background: transparent;
    color: #495057;
    border-radius: 6px;
    padding: 7px 16px;
    cursor: pointer;
    font-size: 13px;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    margin-top: 4px;
    transition: border-color .15s, color .15s, background .15s;
}
.btn-hw-add:hover { border-color: #495057; background: #f8f9fa; color: #212529; }
#hw-empty { color: #adb5bd; font-size: 13px; padding: 12px 0 4px; display: none; }
</style>

<form method="post" enctype="multipart/form-data">

  <div class="form-section">
    <div class="form-section-title"><i class="bi bi-info-circle"></i> Basic Information</div>
    <div class="row g-3">
      <div class="col-md-4"><label class="form-label">Asset Code *</label><input class="form-control" name="asset_code" value="<?= e($asset['asset_code']) ?>" required></div>
      <div class="col-md-4"><label class="form-label">Asset Name *</label><input class="form-control" name="asset_name" value="<?= e($asset['asset_name']) ?>" required></div>
      <div class="col-md-4"><label class="form-label">Serial Number</label><input class="form-control" name="serial_number" value="<?= e($asset['serial_number']) ?>"></div>

      <div class="col-md-4">
        <label class="form-label">Category *</label>
        <select class="form-select" name="asset_category" required>
          <option value="">-- Select Category --</option>
          <?php foreach(['DESKTOP','MONITOR','LAPTOP','PROJECTOR','PRINTER','OTHERS'] as $cat): ?>
            <option value="<?= $cat ?>" <?= $asset['asset_category']===$cat?'selected':'' ?>><?= $cat ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4"><label class="form-label">Brand</label><input class="form-control" name="brand" value="<?= e($asset['brand']) ?>"></div>
      <div class="col-md-4"><label class="form-label">Model</label><input class="form-control" name="model" value="<?= e($asset['model']) ?>"></div>
      <div class="col-md-4"><label class="form-label">Purchase Date</label><input type="date" class="form-control" name="purchase_date" value="<?= e($asset['purchase_date']) ?>"></div>
      <div class="col-md-4"><label class="form-label">Warranty Date</label><input type="date" class="form-control" name="warranty_date" value="<?= e($asset['warranty_date']) ?>"></div>

      <div class="col-md-4">
        <label class="form-label">Manufacturer Year</label>
        <select class="form-select" name="manufacturer_year">
          <option value="">-- Select Year --</option>
          <?php for ($year = date('Y'); $year >= 2000; $year--): ?>
            <option value="<?= $year ?>" <?= $asset['manufacturer_year']==$year?'selected':'' ?>><?= $year ?></option>
          <?php endfor; ?>
        </select>
      </div>
    </div>
  </div>

  <div class="form-section">
    <div class="form-section-title"><i class="bi bi-cpu"></i> Hardware Specification</div>
    <div id="hw-list">
      <?php foreach ($hardware_rows as $i => $hw): ?>
      <div class="hw-row" id="hw-row-<?= $i ?>">
        <div>
          <label>Jenis Hardware</label>
          <select class="form-select form-select-sm" name="hardware[<?= $i ?>][type]">
            <?php foreach(['motherboard'=>'Motherboard','cpu'=>'CPU','ram'=>'RAM','storage'=>'Storage','gpu'=>'GPU','psu'=>'PSU','monitor'=>'Monitor','keyboard'=>'Keyboard','mouse'=>'Mouse','os'=>'Operating System','others'=>'Others'] as $k=>$lbl): ?>
              <option value="<?= $k ?>" <?= $hw['type']===$k?'selected':'' ?>><?= $lbl ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div>
          <label>Spesifikasi</label>
          <input type="text" class="form-control form-control-sm" name="hardware[<?= $i ?>][value]" value="<?= e($hw['value']) ?>" placeholder="Contoh: Intel Core i7-13700K">
        </div>
        <button type="button" class="btn-hw-remove" onclick="hwRemove(<?= $i ?>)" title="Padam baris"><i class="bi bi-trash"></i></button>
      </div>
      <?php endforeach; ?>
    </div>
    <div id="hw-empty">Tiada spesifikasi. Klik butang di bawah untuk tambah.</div>
    <button type="button" class="btn-hw-add" onclick="hwAdd()"><i class="bi bi-plus-lg"></i> Add Hardware</button>
  </div>

  <div class="form-section">
    <div class="form-section-title"><i class="bi bi-person-badge"></i> User & Branch</div>
    <div class="row g-3">
      <div class="col-md-4"><label class="form-label">Used By *</label><input class="form-control" name="use_by" value="<?= e($asset['use_by']) ?>" required></div>

      <div class="col-md-4">
        <label class="form-label">Department *</label>
        <select class="form-select" name="department" required>
          <option value="">-- Select Department --</option>
          <?php foreach(['IT','IT ASSET','PROCESSING','SALES','LEGAL','MEMBERSHIP','COLLECTION','ADMIN','ACCOUNT','GROUP SUPPORT SERVICES','KDSB'] as $dept): ?>
            <option value="<?= $dept ?>" <?= $asset['department']===$dept?'selected':'' ?>><?= $dept ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <!-- ══ Branch — select dropdown ══ -->
      <div class="col-md-4">
        <label class="form-label">Branch *</label>
        <select class="form-select" name="building" required>
          <option value="">-- Select Branch --</option>
          <?php foreach ($branches as $branch): ?>
            <option value="<?= e($branch) ?>" <?= $asset['building'] === $branch ? 'selected' : '' ?>>
              <?= e($branch) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-md-4"><label class="form-label">Floor *</label><input class="form-control" name="floor" value="<?= e($asset['floor']) ?>" required></div>
      <div class="col-md-4"><label class="form-label">Building</label><input class="form-control" name="location" value="<?= e($asset['location']) ?>"></div>

      <div class="col-md-4">
        <label class="form-label">Status *</label>
        <select class="form-select" name="status" required>
          <?php foreach(['Available','Used By','Borrowed','Maintenance','Damaged','Disposed'] as $s): ?>
            <option value="<?= $s ?>" <?= $asset['status']===$s?'selected':'' ?>><?= $s ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" rows="2" name="remarks"><?= e($asset['remarks']) ?></textarea></div>
    </div>
  </div>

  <div class="form-section">
    <div class="form-section-title"><i class="bi bi-paperclip"></i> Attachments</div>
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Main Image</label>
        <input type="file" name="image" accept="image/*" class="form-control">
        <?php if (!empty($asset['image'])): ?>
          <div class="mt-2"><img src="<?= UPLOAD_URL.e($asset['image']) ?>" style="max-height:80px;border-radius:8px"></div>
        <?php endif; ?>
      </div>
      <div class="col-md-6">
        <label class="form-label">Additional Files (JPG, PNG, PDF, DOCX, XLSX) — multiple</label>
        <input type="file" name="files[]" multiple class="form-control" accept=".jpg,.jpeg,.png,.pdf,.docx,.xlsx,.doc,.xls">
      </div>
    </div>
  </div>

  <div class="d-flex gap-2">
    <button class="btn btn-gradient"><i class="bi bi-save"></i> Save Asset</button>
    <a href="list.php" class="btn btn-light">Cancel</a>
  </div>
</form>

<script>
(function () {
    var hwCounter = <?= count($hardware_rows) ?>;
    var hwTypes = {
        motherboard : 'Motherboard',
        cpu         : 'CPU',
        ram         : 'RAM',
        storage     : 'Storage',
        gpu         : 'GPU',
        psu         : 'PSU',
        monitor     : 'Monitor',
        keyboard    : 'Keyboard',
        mouse       : 'Mouse',
        os          : 'Operating System',
        others      : 'Others'
    };
    function buildOptions(selected) {
        return Object.entries(hwTypes).map(function([val,lbl]) {
            return '<option value="'+val+'"'+(val===selected?' selected':'')+'>'+lbl+'</option>';
        }).join('');
    }
    window.hwAdd = function(selectedType, selectedValue) {
        selectedType  = selectedType  || '';
        selectedValue = selectedValue || '';
        var idx = hwCounter++;
        var div = document.createElement('div');
        div.className = 'hw-row';
        div.id = 'hw-row-'+idx;
        div.innerHTML =
            '<div><label>Jenis Hardware</label>' +
            '<select class="form-select form-select-sm" name="hardware['+idx+'][type]">'+buildOptions(selectedType)+'</select></div>' +
            '<div><label>Spesifikasi</label>' +
            '<input type="text" class="form-control form-control-sm" name="hardware['+idx+'][value]" value="'+selectedValue.replace(/"/g,'&quot;')+'" placeholder="Contoh: Intel Core i7-13700K"></div>' +
            '<button type="button" class="btn-hw-remove" onclick="hwRemove('+idx+')" title="Padam baris"><i class="bi bi-trash"></i></button>';
        document.getElementById('hw-list').appendChild(div);
        updateEmpty();
        div.querySelector('input[type="text"]').focus();
    };
    window.hwRemove = function(idx) {
        var el = document.getElementById('hw-row-'+idx);
        if (el) {
            el.style.opacity='0'; el.style.transform='translateX(-8px)';
            el.style.transition='opacity .15s, transform .15s';
            setTimeout(function(){ el.remove(); updateEmpty(); }, 150);
        }
    };
    function updateEmpty() {
        var list  = document.getElementById('hw-list');
        var empty = document.getElementById('hw-empty');
        empty.style.display = list.children.length===0 ? 'block' : 'none';
    }
    updateEmpty();
})();
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>