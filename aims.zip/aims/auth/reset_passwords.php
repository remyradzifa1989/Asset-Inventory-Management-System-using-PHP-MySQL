<?php
// Run ONCE after install to set default admin/staff passwords properly.
require_once __DIR__ . '/../includes/config.php';
$pairs = [['admin','admin123'], ['staff','staff123']];
foreach ($pairs as [$u,$p]) {
    $hash = password_hash($p, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("UPDATE users SET password=? WHERE username=?");
    $stmt->bind_param('ss', $hash, $u);
    $stmt->execute();
    $stmt->close();
}
echo "Passwords reset. admin/admin123  staff/staff123. <strong>Delete this file now.</strong>";
