<?php
require_once __DIR__ . '/../includes/config.php';
if (!empty($_SESSION['user_id'])) log_activity($_SESSION['user_id'], 'LOGOUT', 'User logged out');
session_destroy();
header('Location: ' . BASE_URL . 'auth/login.php');
exit;
