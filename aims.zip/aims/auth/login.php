<?php
require_once __DIR__ . '/../includes/config.php';

if (!empty($_SESSION['user_id'])) {
    header('Location: ' . BASE_URL . 'dashboard.php'); exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    if ($username === '' || $password === '') {
        $error = 'Please enter your username and password.';
    } else {
        $stmt = $conn->prepare("SELECT id, fullname, username, password, role FROM users WHERE username=? LIMIT 1");
        $stmt->bind_param('s', $username);
        $stmt->execute();
        $res = $stmt->get_result()->fetch_assoc();
        $stmt->close();
        if ($res && password_verify($password, $res['password'])) {
            $_SESSION['user_id']       = $res['id'];
            $_SESSION['fullname']      = $res['fullname'];
            $_SESSION['username']      = $res['username'];
            $_SESSION['role']          = $res['role'];
            $_SESSION['last_activity'] = time();
            log_activity($res['id'], 'LOGIN', 'User logged in');
            header('Location: ' . BASE_URL . 'dashboard.php'); exit;
        }
        $error = 'Invalid username or password.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign In · <?= APP_NAME ?></title>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap">
<style>
/* ── Reset ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

html, body {
  height: 100%;
  font-family: 'Inter', system-ui, sans-serif;
  font-size: 15px;
  background: #0f172a;
}

/* ── Layout ── */
.login-wrapper {
  display: flex;
  min-height: 100vh;
}

/* ── Left panel ── */
.l-panel {
  width: 42%;
  background: #0f172a;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  padding: 48px 40px;
  position: relative;
  overflow: hidden;
}

/* Subtle orb decorations */
.l-panel::before {
  content: '';
  position: absolute;
  top: -100px; left: -100px;
  width: 380px; height: 380px;
  border-radius: 50%;
  background: rgba(99, 102, 241, .13);
  pointer-events: none;
}
.l-panel::after {
  content: '';
  position: absolute;
  bottom: -80px; right: -80px;
  width: 260px; height: 260px;
  border-radius: 50%;
  background: rgba(99, 102, 241, .08);
  pointer-events: none;
}

/* Brand */
.l-brand { display: flex; flex-direction: column; align-items: center; text-align: center; z-index: 1; }
.l-logo {
  width: 56px; height: 56px;
  border-radius: 16px;
  background: #6366f1;
  display: flex; align-items: center; justify-content: center;
  font-size: 26px; color: #fff;
  margin-bottom: 18px;
}
.l-app-name {
  font-size: 26px; font-weight: 700;
  color: #fff; letter-spacing: -.4px;
}
.l-app-full {
  font-size: 12.5px;
  color: rgba(255,255,255,.45);
  margin-top: 6px;
  line-height: 1.5;
  max-width: 200px;
}

/* Feature pills */
.l-features { display: flex; flex-direction: column; gap: 10px; margin-top: 36px; width: 100%; z-index: 1; }
.l-feat {
  display: flex; align-items: center; gap: 12px;
  background: rgba(255,255,255,.05);
  border: 0.5px solid rgba(255,255,255,.09);
  border-radius: 12px;
  padding: 12px 15px;
}
.l-feat-icon {
  width: 32px; height: 32px;
  border-radius: 8px;
  display: flex; align-items: center; justify-content: center;
  font-size: 16px;
  flex-shrink: 0;
}
.l-feat-text strong {
  display: block;
  font-size: 13px; font-weight: 600;
  color: rgba(255,255,255,.88);
}
.l-feat-text span {
  font-size: 12px;
  color: rgba(255,255,255,.45);
}

/* Footer credit */
.l-footer {
  position: absolute; bottom: 24px;
  font-size: 11px; color: rgba(255,255,255,.25);
  z-index: 1;
}

/* ── Right panel ── */
.r-panel {
  flex: 1;
  background: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 48px 40px;
}

.login-box { width: 100%; max-width: 360px; }

.lb-heading {
  font-size: 24px; font-weight: 700;
  color: #0f172a; letter-spacing: -.4px;
  margin-bottom: 5px;
}
.lb-sub {
  font-size: 13.5px; color: #64748b;
  margin-bottom: 30px;
}

/* Error alert */
.lb-error {
  display: flex; align-items: flex-start; gap: 9px;
  background: #fef2f2;
  border: 0.5px solid #fecaca;
  border-radius: 10px;
  padding: 11px 14px;
  font-size: 13px; color: #b91c1c;
  margin-bottom: 20px;
}
.lb-error i { font-size: 16px; flex-shrink: 0; margin-top: 1px; }

/* Form fields */
.lb-group { margin-bottom: 18px; }
.lb-label {
  display: block;
  font-size: 12px; font-weight: 600;
  color: #374151;
  text-transform: uppercase; letter-spacing: .3px;
  margin-bottom: 7px;
}
.lb-field {
  position: relative;
}
.lb-field input {
  width: 100%;
  border: 1px solid #e2e8f0;
  border-radius: 11px;
  padding: 12px 44px 12px 15px;
  font-size: 14px; font-family: inherit;
  color: #0f172a;
  background: #f8fafc;
  outline: none;
  transition: border .15s, background .15s, box-shadow .15s;
}
.lb-field input::placeholder { color: #94a3b8; }
.lb-field input:focus {
  border-color: #6366f1;
  background: #fff;
  box-shadow: 0 0 0 3px rgba(99,102,241,.14);
}
.lb-field .field-icon {
  position: absolute; right: 14px; top: 50%;
  transform: translateY(-50%);
  color: #94a3b8; font-size: 17px;
  pointer-events: none;
}
.lb-field .pw-toggle {
  position: absolute; right: 12px; top: 50%;
  transform: translateY(-50%);
  color: #94a3b8; font-size: 16px;
  background: none; border: none; cursor: pointer;
  padding: 2px; display: flex;
  transition: color .15s;
}
.lb-field .pw-toggle:hover { color: #6366f1; }

/* Remember me */
.lb-check {
  display: flex; align-items: center; gap: 8px;
  margin-bottom: 24px;
}
.lb-check input[type="checkbox"] {
  width: 16px; height: 16px;
  accent-color: #6366f1;
  cursor: pointer;
}
.lb-check label {
  font-size: 13px; color: #64748b; cursor: pointer;
}

/* Submit button */
.lb-btn {
  width: 100%;
  padding: 13px;
  border-radius: 11px;
  background: #6366f1;
  color: #fff;
  font-size: 14.5px; font-weight: 600; font-family: inherit;
  border: none; cursor: pointer;
  display: flex; align-items: center; justify-content: center; gap: 8px;
  letter-spacing: .1px;
  transition: background .15s, transform .1s;
}
.lb-btn:hover  { background: #4f46e5; }
.lb-btn:active { transform: scale(.98); }
.lb-btn:disabled { opacity: .7; cursor: not-allowed; }

/* Credential hint */
.lb-hint {
  margin-top: 20px;
  background: #f8fafc;
  border: 0.5px solid #e2e8f0;
  border-radius: 10px;
  padding: 12px 15px;
}
.lb-hint-title {
  font-size: 10.5px; font-weight: 600;
  color: #94a3b8; text-transform: uppercase;
  letter-spacing: .4px; margin-bottom: 8px;
}
.lb-hint-row {
  display: flex; align-items: center; justify-content: space-between;
  font-size: 12.5px; color: #475569;
  margin-bottom: 5px;
}
.lb-hint-row:last-child { margin-bottom: 0; }
.lb-hint-row span {
  font-family: ui-monospace, 'Cascadia Code', monospace;
  background: #e2e8f0; border-radius: 5px;
  padding: 1px 8px; font-size: 12px;
  color: #334155;
}

/* ── Responsive ── */
@media (max-width: 700px) {
  .l-panel { display: none; }
  .r-panel  { padding: 32px 24px; }
}
</style>
</head>
<body>

<div class="login-wrapper">

  <!-- ═══ Left panel ═══ -->
  <div class="l-panel">
    <div class="l-brand">
      <div class="l-logo"><i class="bi bi-boxes"></i></div>
      <div class="l-app-name"><?= APP_NAME ?></div>
      <div class="l-app-full"><?= APP_FULL ?></div>
    </div>

    <div class="l-features">
      <div class="l-feat">
        <div class="l-feat-icon" style="background:rgba(99,102,241,.2);color:#a5b4fc">
          <i class="bi bi-pc-display"></i>
        </div>
        <div class="l-feat-text">
          <strong>Track Assets</strong>
          <span>Manage all items in one place</span>
        </div>
      </div>
      <div class="l-feat">
        <div class="l-feat-icon" style="background:rgba(16,185,129,.15);color:#6ee7b7">
          <i class="bi bi-arrow-left-right"></i>
        </div>
        <div class="l-feat-text">
          <strong>Borrow &amp; Return</strong>
          <span>Streamlined lending records</span>
        </div>
      </div>
      <div class="l-feat">
        <div class="l-feat-icon" style="background:rgba(245,158,11,.15);color:#fcd34d">
          <i class="bi bi-tools"></i>
        </div>
        <div class="l-feat-text">
          <strong>Maintenance Alerts</strong>
          <span>Never miss a service date</span>
        </div>
      </div>
      <div class="l-feat">
        <div class="l-feat-icon" style="background:rgba(236,72,153,.15);color:#f9a8d4">
          <i class="bi bi-bar-chart-fill"></i>
        </div>
        <div class="l-feat-text">
          <strong>Live Dashboard</strong>
          <span>Real-time overview &amp; reports</span>
        </div>
      </div>
    </div>

    <div class="l-footer">&copy; <?= date('Y') ?> <?= APP_NAME ?></div>
  </div>

  <!-- ═══ Right panel ═══ -->
  <div class="r-panel">
    <div class="login-box">
      <h1 class="lb-heading">Welcome back</h1>
      <p class="lb-sub">Sign in to your AIMS account</p>

      <?php if ($error): ?>
      <div class="lb-error">
        <i class="bi bi-exclamation-circle-fill"></i>
        <?= e($error) ?>
      </div>
      <?php endif; ?>

      <form method="post" autocomplete="off">

        <div class="lb-group">
          <label class="lb-label" for="username">Username</label>
          <div class="lb-field">
            <input
              type="text"
              id="username"
              name="username"
              placeholder="Enter your username"
              value="<?= e($_POST['username'] ?? '') ?>"
              required
              autocomplete="username"
            >
            <i class="bi bi-person field-icon"></i>
          </div>
        </div>

        <div class="lb-group">
          <label class="lb-label" for="pw">Password</label>
          <div class="lb-field">
            <input
              type="password"
              id="pw"
              name="password"
              placeholder="••••••••"
              required
              autocomplete="current-password"
            >
            <button type="button" class="pw-toggle" id="eyeBtn" aria-label="Toggle password visibility">
              <i class="bi bi-eye" id="eyeIcon"></i>
            </button>
          </div>
        </div>

        <div class="lb-check">
          <input type="checkbox" id="remember" name="remember">
          <label for="remember">Remember me</label>
        </div>

        <button type="submit" class="lb-btn" id="loginBtn">
          <i class="bi bi-box-arrow-in-right"></i> Sign In
        </button>

      </form>

      

    </div>
  </div>
</div>

<script>
/* Password toggle */
document.getElementById('eyeBtn').addEventListener('click', function () {
  const pw = document.getElementById('pw');
  const ic = document.getElementById('eyeIcon');
  if (pw.type === 'password') {
    pw.type = 'text';
    ic.className = 'bi bi-eye-slash';
  } else {
    pw.type = 'password';
    ic.className = 'bi bi-eye';
  }
});

/* Loading state on submit */
document.querySelector('form').addEventListener('submit', function () {
  const btn = document.getElementById('loginBtn');
  btn.innerHTML = '<span class="spinner-border spinner-border-sm" style="width:14px;height:14px;border-width:2px"></span> Signing in…';
  btn.disabled = true;
});
</script>

</body>
</html>