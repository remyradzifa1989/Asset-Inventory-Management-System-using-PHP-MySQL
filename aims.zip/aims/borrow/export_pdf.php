<?php
require_once __DIR__ . '/../includes/config.php';
require_login();

$where = []; $params = []; $types = '';
if (!empty($_GET['asset_name'])) { $where[] = "a.asset_name LIKE ?"; $params[] = '%'.$_GET['asset_name'].'%'; $types .= 's'; }
if (!empty($_GET['borrow_by']))  { $where[] = "b.borrow_by LIKE ?";  $params[] = '%'.$_GET['borrow_by'].'%';  $types .= 's'; }
if (!empty($_GET['department'])) { $where[] = "b.department = ?";    $params[] = $_GET['department'];          $types .= 's'; }
if (!empty($_GET['borrow_date'])){ $where[] = "b.borrow_date = ?";   $params[] = $_GET['borrow_date'];         $types .= 's'; }
if (!empty($_GET['return_date'])){ $where[] = "b.return_date = ?";   $params[] = $_GET['return_date'];         $types .= 's'; }
if (!empty($_GET['status']))     { $where[] = "b.status = ?";        $params[] = $_GET['status'];              $types .= 's'; }

$sql = "SELECT b.*, a.asset_code, a.asset_name FROM borrow_records b LEFT JOIN assets a ON a.id=b.asset_id";
if ($where) $sql .= " WHERE ".implode(" AND ",$where);
$sql .= " ORDER BY b.id DESC";
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types,...$params);
$stmt->execute();
$rows = $stmt->get_result();
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Borrow Records</title>
<style>
  body { font-family: Arial, sans-serif; font-size: 12px; }
  h2 { text-align: center; margin-bottom: 4px; }
  p.sub { text-align: center; color: #666; margin-bottom: 16px; font-size: 11px; }
  table { width: 100%; border-collapse: collapse; }
  th { background: #2563eb; color: #fff; padding: 6px 8px; text-align: left; }
  td { padding: 5px 8px; border-bottom: 1px solid #e5e7eb; }
  tr:nth-child(even) td { background: #f8fafc; }
  .badge { padding: 2px 8px; border-radius: 10px; font-size: 11px; }
  .b-approved    { background:#d1fae5; color:#065f46; }
  .b-returned    { background:#dbeafe; color:#1e40af; }
  .b-late-return { background:#fee2e2; color:#991b1b; }
  @media print {
    .no-print { display: none; }
    body { margin: 0; }
  }
</style>
</head>
<body>
<h2>Borrow Records Report</h2>
<p class="sub">Generated: <?= date('d M Y, h:i A') ?></p>

<div class="no-print" style="text-align:center; margin-bottom:16px;">
  <button onclick="window.print()" style="padding:8px 24px; background:#2563eb; color:#fff; border:none; border-radius:6px; cursor:pointer; font-size:13px;">
    🖨️ Print / Save as PDF
  </button>
  <button onclick="window.close()" style="padding:8px 16px; background:#e5e7eb; border:none; border-radius:6px; cursor:pointer; margin-left:8px;">
    Close
  </button>
</div>

<table>
<thead>
  <tr><th>ID</th><th>Asset Code</th><th>Asset Name</th><th>Borrowed By</th><th>Department</th><th>Borrow Date</th><th>Return Date</th><th>Status</th></tr>
</thead>
<tbody>
<?php while($b=$rows->fetch_assoc()):
  $return_date = ($b['status']==='Returned'||$b['status']==='Late Return') ? $b['actual_return_date'] : $b['return_date'];
  $badge_class = 'b-'.strtolower(str_replace(' ','-',$b['status']));
?>
<tr>
  <td>#<?= $b['id'] ?></td>
  <td><?= htmlspecialchars($b['asset_code']) ?></td>
  <td><?= htmlspecialchars($b['asset_name']) ?></td>
  <td><?= htmlspecialchars($b['borrow_by']) ?></td>
  <td><?= htmlspecialchars($b['department']) ?></td>
  <td><?= htmlspecialchars($b['borrow_date']) ?></td>
  <td><?= htmlspecialchars($return_date) ?></td>
  <td><span class="badge <?= $badge_class ?>"><?= htmlspecialchars($b['status']) ?></span></td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</body>
</html>