<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$page_title='Borrow Asset'; $active='borrow';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $aid=(int)$_POST['asset_id']; $by=trim($_POST['borrow_by']); $dep=trim($_POST['department']);
    $bd=$_POST['borrow_date']; $rd=$_POST['return_date'] ?: null; $st=$_POST['status']; $rm=trim($_POST['remarks']);
    $stmt=$conn->prepare("INSERT INTO borrow_records (asset_id,borrow_by,department,borrow_date,return_date,status,remarks) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param('issssss',$aid,$by,$dep,$bd,$rd,$st,$rm); $stmt->execute();
    if ($st==='Approved') $conn->query("UPDATE assets SET status='Borrowed' WHERE id=$aid");
    log_activity($_SESSION['user_id'],'BORROW_CREATE','Borrow record for asset #'.$aid);
    header('Location: list.php'); exit;
}
$assets = $conn->query("SELECT id,asset_code,asset_name,status FROM assets WHERE status='Available' ORDER BY asset_code");
include __DIR__ . '/../includes/header.php';
?>
<form method="post">
<div class="form-section">
  <div class="form-section-title"><i class="bi bi-arrow-left-right"></i> Borrow Form</div>
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Asset *</label>
      <select name="asset_id" class="form-select" required>
        <option value="">-- Select Asset --</option>
        <?php while($a=$assets->fetch_assoc()): ?>
  <option value="<?= $a['id'] ?>"><?= e($a['asset_code']) ?> · <?= e($a['asset_name']) ?></option>
<?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-6"><label class="form-label">Borrowed By *</label><input class="form-control" name="borrow_by" value="<?= e($_SESSION['fullname']) ?>" required></div>
    <div class="col-md-4">
      <label class="form-label">Department *</label>
      <select class="form-select" name="department" required>
        <option value="">-- Select Department --</option>
        <?php foreach(['IT','IT ASSET','PROCESSING','SALES','LEGAL','MEMBERSHIP','COLLECTION','ADMIN','ACCOUNT','GROUP SUPPORT SERVICES','KDSB'] as $dept): ?>
          <option value="<?= $dept ?>"><?= $dept ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-3"><label class="form-label">Borrow Date *</label><input type="date" class="form-control" name="borrow_date" value="<?= date('Y-m-d') ?>" required></div>
    <!-- <div class="col-md-3"><label class="form-label">Return Date</label><input type="date" class="form-control" name="return_date"></div> -->
    <div class="col-md-4"><label class="form-label">Status</label>
      <select name="status" class="form-select">
        <?php foreach(['Approved','Returned','Late Return'] as $s): ?>
          <option value="<?= $s ?>"><?= $s ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" rows="2"></textarea></div>
  </div>
</div>
<button class="btn btn-gradient"><i class="bi bi-save"></i> Submit Borrow</button>
<a href="list.php" class="btn btn-light">Cancel</a>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>