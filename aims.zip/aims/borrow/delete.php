<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();
$id=(int)$_GET['id'];
$conn->query("DELETE FROM borrow_records WHERE id=$id");
log_activity($_SESSION['user_id'],'BORROW_DELETE','Deleted borrow #'.$id);
header('Location: list.php'); exit;
