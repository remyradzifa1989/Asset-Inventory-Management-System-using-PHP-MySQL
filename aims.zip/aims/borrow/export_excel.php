<?php
require_once __DIR__ . '/../includes/config.php';
require_login();

require_once __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\Font;

// ── Filter (sama macam list.php) ──────────────────────────────────────────
$where = []; $params = []; $types = '';
if (!empty($_GET['asset_name'])) { $where[] = "a.asset_name LIKE ?"; $params[] = '%'.$_GET['asset_name'].'%'; $types .= 's'; }
if (!empty($_GET['borrow_by']))  { $where[] = "b.borrow_by LIKE ?";  $params[] = '%'.$_GET['borrow_by'].'%';  $types .= 's'; }
if (!empty($_GET['department'])) { $where[] = "b.department = ?";    $params[] = $_GET['department'];          $types .= 's'; }
if (!empty($_GET['borrow_date'])){ $where[] = "b.borrow_date = ?";   $params[] = $_GET['borrow_date'];         $types .= 's'; }
if (!empty($_GET['return_date'])){ $where[] = "b.return_date = ?";   $params[] = $_GET['return_date'];         $types .= 's'; }
if (!empty($_GET['status']))     { $where[] = "b.status = ?";        $params[] = $_GET['status'];              $types .= 's'; }

$sql = "SELECT b.*, a.asset_code, a.asset_name FROM borrow_records b LEFT JOIN assets a ON a.id=b.asset_id";
if ($where) $sql .= " WHERE ".implode(" AND ",$where);
$sql .= " ORDER BY b.id DESC";
$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types,...$params);
$stmt->execute();
$rows = $stmt->get_result();
$data = $rows->fetch_all(MYSQLI_ASSOC);

// ── Spreadsheet setup ─────────────────────────────────────────────────────
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Borrow Records');

// Tetapkan lebar kolum
$sheet->getColumnDimension('A')->setWidth(6);
$sheet->getColumnDimension('B')->setWidth(14);
$sheet->getColumnDimension('C')->setWidth(28);
$sheet->getColumnDimension('D')->setWidth(22);
$sheet->getColumnDimension('E')->setWidth(22);
$sheet->getColumnDimension('F')->setWidth(14);
$sheet->getColumnDimension('G')->setWidth(14);
$sheet->getColumnDimension('H')->setWidth(14);

// ── Row 1: Title ──────────────────────────────────────────────────────────
$sheet->mergeCells('A1:H1');
$sheet->setCellValue('A1', 'BORROW RECORDS REPORT');
$sheet->getStyle('A1')->applyFromArray([
    'font'      => ['bold' => true, 'size' => 14, 'color' => ['rgb' => 'FFFFFF']],
    'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '1D4ED8']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
]);
$sheet->getRowDimension(1)->setRowHeight(32);

// ── Row 2: Generated date ─────────────────────────────────────────────────
$sheet->mergeCells('A2:H2');
$sheet->setCellValue('A2', 'Generated: ' . date('d M Y, h:i A'));
$sheet->getStyle('A2')->applyFromArray([
    'font'      => ['italic' => true, 'size' => 9, 'color' => ['rgb' => '6B7280']],
    'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'EFF6FF']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
]);
$sheet->getRowDimension(2)->setRowHeight(18);

// ── Row 3: Filter info (kalau ada filter) ─────────────────────────────────
$filter_labels = [];
if (!empty($_GET['asset_name'])) $filter_labels[] = 'Asset: '.$_GET['asset_name'];
if (!empty($_GET['borrow_by']))  $filter_labels[] = 'Borrowed By: '.$_GET['borrow_by'];
if (!empty($_GET['department'])) $filter_labels[] = 'Dept: '.$_GET['department'];
if (!empty($_GET['status']))     $filter_labels[] = 'Status: '.$_GET['status'];

$sheet->mergeCells('A3:H3');
$sheet->setCellValue('A3', $filter_labels ? 'Filter: '.implode('  |  ', $filter_labels) : 'Filter: None (All Records)');
$sheet->getStyle('A3')->applyFromArray([
    'font'      => ['size' => 9, 'color' => ['rgb' => '374151']],
    'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'DBEAFE']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
]);
$sheet->getRowDimension(3)->setRowHeight(16);

// ── Row 4: Blank spacer ───────────────────────────────────────────────────
$sheet->getRowDimension(4)->setRowHeight(6);

// ── Row 5: Header kolum ───────────────────────────────────────────────────
$headers = ['No.', 'Asset Code', 'Asset Name', 'Borrowed By', 'Department', 'Borrow Date', 'Return Date', 'Status'];
$headerRow = 5;
foreach ($headers as $i => $h) {
    $col = chr(65 + $i);
    $sheet->setCellValue($col.$headerRow, $h);
}
$sheet->getStyle('A5:H5')->applyFromArray([
    'font'      => ['bold' => true, 'size' => 10, 'color' => ['rgb' => 'FFFFFF']],
    'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '1E40AF']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
    'borders'   => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'BFDBFE']]],
]);
$sheet->getRowDimension(5)->setRowHeight(22);

// ── Data rows ─────────────────────────────────────────────────────────────
$no = 1;
$rowNum = 6;
foreach ($data as $b) {
    $return_date = ($b['status']==='Returned'||$b['status']==='Late Return')
        ? $b['actual_return_date'] : $b['return_date'];

    $sheet->setCellValue('A'.$rowNum, $no++);
    $sheet->setCellValue('B'.$rowNum, $b['asset_code']);
    $sheet->setCellValue('C'.$rowNum, $b['asset_name']);
    $sheet->setCellValue('D'.$rowNum, $b['borrow_by']);
    $sheet->setCellValue('E'.$rowNum, $b['department']);
    $sheet->setCellValue('F'.$rowNum, $b['borrow_date']);
    $sheet->setCellValue('G'.$rowNum, $return_date);
    $sheet->setCellValue('H'.$rowNum, $b['status']);

    // Warna selang-seli baris
    $rowBg = ($no % 2 === 0) ? 'F0F9FF' : 'FFFFFF';

    $sheet->getStyle('A'.$rowNum.':H'.$rowNum)->applyFromArray([
        'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => $rowBg]],
        'alignment' => ['vertical' => Alignment::VERTICAL_CENTER],
        'borders'   => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'E5E7EB']]],
        'font'      => ['size' => 10],
    ]);

    // Warna badge status
    $statusColors = [
        'Approved'    => ['bg' => 'D1FAE5', 'font' => '065F46'],
        'Returned'    => ['bg' => 'DBEAFE', 'font' => '1E40AF'],
        'Late Return' => ['bg' => 'FEE2E2', 'font' => '991B1B'],
    ];
    $sc = $statusColors[$b['status']] ?? ['bg' => 'F3F4F6', 'font' => '374151'];
    $sheet->getStyle('H'.$rowNum)->applyFromArray([
        'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => $sc['bg']]],
        'font'      => ['bold' => true, 'color' => ['rgb' => $sc['font']]],
        'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
    ]);

    // Center kolum No., Date
    $sheet->getStyle('A'.$rowNum)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle('F'.$rowNum)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);
    $sheet->getStyle('G'.$rowNum)->getAlignment()->setHorizontal(Alignment::HORIZONTAL_CENTER);

    $sheet->getRowDimension($rowNum)->setRowHeight(20);
    $rowNum++;
}

// ── Row summary ───────────────────────────────────────────────────────────
$sheet->mergeCells('A'.$rowNum.':G'.$rowNum);
$sheet->setCellValue('A'.$rowNum, 'Total Records: '.count($data));
$sheet->setCellValue('H'.$rowNum, '');
$sheet->getStyle('A'.$rowNum.':H'.$rowNum)->applyFromArray([
    'font'      => ['bold' => true, 'size' => 10, 'color' => ['rgb' => '1E40AF']],
    'fill'      => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => 'EFF6FF']],
    'borders'   => ['top' => ['borderStyle' => Border::BORDER_MEDIUM, 'color' => ['rgb' => '1D4ED8']]],
]);
$sheet->getRowDimension($rowNum)->setRowHeight(20);

// ── Freeze header ─────────────────────────────────────────────────────────
$sheet->freezePane('A6');

// ── Output ────────────────────────────────────────────────────────────────
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="BorrowRecords_'.date('d-m-Y').'.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;