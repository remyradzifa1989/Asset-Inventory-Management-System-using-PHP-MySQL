<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$page_title='Borrow Records'; $active='borrow';

$where = []; $params = []; $types = '';

if (!empty($_GET['asset_name'])) { $where[] = "a.asset_name LIKE ?"; $params[] = '%'.$_GET['asset_name'].'%'; $types .= 's'; }
if (!empty($_GET['borrow_by']))  { $where[] = "b.borrow_by LIKE ?";  $params[] = '%'.$_GET['borrow_by'].'%';  $types .= 's'; }
if (!empty($_GET['department'])) { $where[] = "b.department = ?";    $params[] = $_GET['department'];          $types .= 's'; }
if (!empty($_GET['borrow_date'])){ $where[] = "b.borrow_date = ?";   $params[] = $_GET['borrow_date'];         $types .= 's'; }
if (!empty($_GET['return_date'])){ $where[] = "b.return_date = ?";   $params[] = $_GET['return_date'];         $types .= 's'; }
if (!empty($_GET['status']))     { $where[] = "b.status = ?";        $params[] = $_GET['status'];              $types .= 's'; }

$sql = "SELECT b.*, a.asset_code, a.asset_name FROM borrow_records b LEFT JOIN assets a ON a.id=b.asset_id";
if ($where) $sql .= " WHERE " . implode(" AND ", $where);
$sql .= " ORDER BY b.id DESC";

$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$rows = $stmt->get_result();

$export_qs = http_build_query(array_filter($_GET));
include __DIR__ . '/../includes/header.php';
?>

<div class="d-flex justify-content-between mb-3">
  <h5 class="mb-0"><i class="bi bi-arrow-left-right text-primary"></i> Borrow Records</h5>
  <div class="d-flex gap-2">
    <a href="export_excel.php?<?= $export_qs ?>" class="btn btn-success btn-sm"><i class="bi bi-file-earmark-excel"></i> Excel</a>
    <a href="export_pdf.php?<?= $export_qs ?>" class="btn btn-danger btn-sm"><i class="bi bi-file-earmark-pdf"></i> PDF</a>
    <a href="form.php" class="btn btn-gradient btn-sm"><i class="bi bi-plus-lg"></i> New Borrow</a>
  </div>
</div>

<!-- Filter Form -->
<div class="aims-table p-3 mb-3">
  <form method="GET" class="row g-2 align-items-end">
    <div class="col-md-2">
      <label class="form-label small mb-1">Asset Name</label>
      <input type="text" name="asset_name" class="form-control form-control-sm" value="<?= e($_GET['asset_name'] ?? '') ?>" placeholder="Cari asset...">
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1">Borrowed By</label>
      <input type="text" name="borrow_by" class="form-control form-control-sm" value="<?= e($_GET['borrow_by'] ?? '') ?>" placeholder="Nama...">
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1">Department</label>
      <select name="department" class="form-select form-select-sm">
        <option value="">Semua</option>
        <?php foreach(['IT','IT ASSET','PROCESSING','SALES','LEGAL','MEMBERSHIP','COLLECTION','ADMIN','ACCOUNT','GROUP SUPPORT SERVICES','KDSB'] as $dept): ?>
          <option value="<?= $dept ?>" <?= (($_GET['department'] ?? '') === $dept) ? 'selected' : '' ?>><?= $dept ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1">Borrow Date</label>
      <input type="date" name="borrow_date" class="form-control form-control-sm" value="<?= e($_GET['borrow_date'] ?? '') ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1">Return Date</label>
      <input type="date" name="return_date" class="form-control form-control-sm" value="<?= e($_GET['return_date'] ?? '') ?>">
    </div>
    <div class="col-md-1">
      <label class="form-label small mb-1">Status</label>
      <select name="status" class="form-select form-select-sm">
        <option value="">Semua</option>
        <?php foreach(['Approved','Returned','Late Return'] as $s): ?>
          <option value="<?= $s ?>" <?= (($_GET['status'] ?? '') === $s) ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-1 d-flex gap-1">
      <button class="btn btn-primary btn-sm w-100"><i class="bi bi-search"></i></button>
      <a href="list.php" class="btn btn-outline-secondary btn-sm"><i class="bi bi-x"></i></a>
    </div>
  </form>
</div>

<div class="aims-table p-3">
<table class="table aims-dt align-middle w-100">
<thead>
  <tr><th>No.</th><th>Asset Name</th><th>Borrowed By</th><th>Department</th><th>Borrow Date</th><th>Return Date</th><th>Status</th><th>Actions</th></tr>
</thead>
<tbody>
<?php $no = 1; while($b = $rows->fetch_assoc()): ?>
<tr>
  <td class="text-muted text-center"><?= $no++ ?></td>
  <td><strong><?= e($b['asset_code']) ?></strong><br><small class="text-muted"><?= e($b['asset_name']) ?></small></td>
  <td><?= e($b['borrow_by']) ?></td>
  <td><?= e($b['department']) ?></td>
  <td><?= e($b['borrow_date']) ?></td>
  <td>
    <?php if ($b['status'] === 'Returned' || $b['status'] === 'Late Return'): ?>
      <?= e($b['actual_return_date']) ?>
      <br><small class="text-muted">Due: <?= e($b['return_date']) ?></small>
    <?php else: ?>
      <?= e($b['return_date']) ?>
    <?php endif; ?>
  </td>
  <td><span class="badge-status b-<?= strtolower(str_replace(' ','-',$b['status'])) ?>"><?= e($b['status']) ?></span></td>
  <td>
    <?php if ($b['status'] !== 'Returned' && $b['status'] !== 'Late Return'): ?>
      <a href="return.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-success"><i class="bi bi-box-arrow-in-down"></i> Return</a>
    <?php endif; ?>
    <?php if ($_SESSION['role'] === 'ADMIN'): ?>
      <a href="delete.php?id=<?= $b['id'] ?>" class="btn btn-sm btn-outline-danger confirm-delete"><i class="bi bi-trash"></i></a>
    <?php endif; ?>
  </td>
</tr>
<?php endwhile; ?>
</tbody>
</table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>