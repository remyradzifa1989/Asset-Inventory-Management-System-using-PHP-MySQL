<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$id = (int)$_GET['id'];
$b = $conn->query("SELECT b.*, a.asset_code, a.asset_name FROM borrow_records b LEFT JOIN assets a ON a.id=b.asset_id WHERE b.id=$id")->fetch_assoc();

// Proses bila submit form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $actual_return = $_POST['actual_return_date'];
    $today = date('Y-m-d');
    $late = ($b['return_date'] && $actual_return > $b['return_date']) ? 'Late Return' : 'Returned';
    
    $stmt = $conn->prepare("UPDATE borrow_records SET status=?, actual_return_date=?, return_date=? WHERE id=?");
    $stmt->bind_param('sssi', $late, $actual_return, $actual_return, $id);
    $stmt->execute();
    $conn->query("UPDATE assets SET status='Available' WHERE id=" . (int)$b['asset_id']);
    log_activity($_SESSION['user_id'], 'BORROW_RETURN', 'Returned borrow #' . $id);
    header('Location: list.php');
    exit;
}

$today = date('Y-m-d');
$page_title = 'Return Asset';
$active = 'borrow';
include __DIR__ . '/../includes/header.php';
?>

<div class="mb-3">
  <h5><i class="bi bi-box-arrow-in-down text-success"></i> Return Asset</h5>
</div>

<div class="aims-table p-4" style="max-width:500px;">
  <table class="table table-borderless mb-4">
    <tr><th>Asset</th><td><?= e($b['asset_code']) ?> — <?= e($b['asset_name']) ?></td></tr>
    <tr><th>Borrowed By</th><td><?= e($b['borrow_by']) ?></td></tr>
    <tr><th>Department</th><td><?= e($b['department']) ?></td></tr>
    <tr><th>Borrow Date</th><td><?= e($b['borrow_date']) ?></td></tr>
    <tr><th>Due Date</th><td><?= e($b['return_date']) ?></td></tr>
  </table>

  <form method="POST">
    <div class="mb-3">
      <label class="form-label fw-semibold">Return Date</label>
      <input type="date" name="actual_return_date" class="form-control"
             value="<?= $today ?>" required>
      <div class="form-text">Default hari ini. Boleh ubah jika perlu.</div>
    </div>
    <div class="d-flex gap-2">
      <button type="submit" class="btn btn-success"><i class="bi bi-check-lg"></i> Confirm Return</button>
      <a href="list.php" class="btn btn-outline-secondary">Cancel</a>
    </div>
  </form>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>