// AIMS — UI helpers
document.addEventListener('DOMContentLoaded', () => {
  // Sidebar toggle (mobile)
  const sb = document.querySelector('.aims-sidebar');
  document.getElementById('sbToggle')?.addEventListener('click', () => sb?.classList.toggle('open'));

  // Dark mode
  const dt = document.getElementById('darkToggle');
  if (localStorage.getItem('aims-dark') === '1') document.body.classList.add('dark');
  dt?.addEventListener('click', () => {
    document.body.classList.toggle('dark');
    localStorage.setItem('aims-dark', document.body.classList.contains('dark') ? '1' : '0');
  });

  // Animated counters
  document.querySelectorAll('[data-counter]').forEach(el => {
    const target = parseInt(el.dataset.counter, 10) || 0;
    let cur = 0; const step = Math.max(1, Math.floor(target / 40));
    const tick = () => { cur += step; if (cur >= target) { el.textContent = target; return; } el.textContent = cur; requestAnimationFrame(tick); };
    tick();
  });

  // DataTables auto-init
  if (window.jQuery && jQuery.fn.DataTable) {
    jQuery('table.aims-dt').DataTable({ pageLength: 10, order: [[0, 'desc']], language: { search: '', searchPlaceholder: 'Search...' } });
  }

  // Delete confirm
  document.querySelectorAll('a.confirm-delete, button.confirm-delete').forEach(el => {
    el.addEventListener('click', (e) => {
      e.preventDefault();
      Swal.fire({
        title: 'Are you sure?', text: 'This action cannot be undone.', icon: 'warning',
        showCancelButton: true, confirmButtonColor: '#ef4444', confirmButtonText: 'Yes, delete'
      }).then(r => { if (r.isConfirmed) window.location = el.getAttribute('href') || el.dataset.href; });
    });
  });
});

// Toast helper
window.toast = (icon, title) => Swal.fire({ toast:true, position:'top-end', icon, title, showConfirmButton:false, timer:2200 });
