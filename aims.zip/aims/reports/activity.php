<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();

$page_title='Activity Logs';
$active='activity';

$rows = $conn->query("
    SELECT l.*, u.fullname
    FROM activity_logs l
    LEFT JOIN users u ON u.id=l.user_id
    ORDER BY l.id DESC
    LIMIT 500
");

include __DIR__ . '/../includes/header.php';
?>

<div class="aims-table p-3">
<table class="table aims-dt align-middle w-100">
<thead>
<tr>
    <th>No.</th>
    <th>User</th>
    <th>Action</th>
    <th>Description</th>
    <th>Date</th>
</tr>
</thead>

<tbody>

<?php $no = 1; ?>

<?php while($l=$rows->fetch_assoc()): ?>

<tr>
    <td><?= $no++ ?></td>

    <td><?= e($l['fullname'] ?: 'system') ?></td>

    <td>
        <span class="badge text-bg-info">
            <?= e($l['action']) ?>
        </span>
    </td>

    <td><?= e($l['description']) ?></td>

    <td><?= e($l['created_at']) ?></td>
</tr>

<?php endwhile; ?>

</tbody>
</table>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>