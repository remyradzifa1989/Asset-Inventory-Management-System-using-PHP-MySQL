<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$page_title = 'Reports'; $active = 'reports';

$by_cat = [];
$r = $conn->query("SELECT IFNULL(NULLIF(asset_category,''),'Uncategorized') c, COUNT(*) n FROM assets GROUP BY c ORDER BY n DESC");
while ($x = $r->fetch_assoc()) $by_cat[$x['c']] = (int)$x['n'];

$by_dep = [];
$r = $conn->query("SELECT IFNULL(NULLIF(department,''),'Unassigned') d, COUNT(*) n FROM assets GROUP BY d ORDER BY n DESC");
while ($x = $r->fetch_assoc()) $by_dep[$x['d']] = (int)$x['n'];

$by_status = [];
$r = $conn->query("SELECT status s, COUNT(*) n FROM assets GROUP BY s ORDER BY n DESC");
while ($x = $r->fetch_assoc()) $by_status[$x['s']] = (int)$x['n'];

$borrow_total = (int)$conn->query("SELECT COUNT(*) c FROM borrow_records")->fetch_assoc()['c'];
$maint_total  = (int)$conn->query("SELECT COUNT(*) c FROM maintenance_records")->fetch_assoc()['c'];
$maint_cost   = (float)$conn->query("SELECT IFNULL(SUM(cost),0) s FROM maintenance_records")->fetch_assoc()['s'];
$damaged      = (int)$conn->query("SELECT COUNT(*) c FROM assets WHERE status IN('Damaged','Disposed')")->fetch_assoc()['c'];

include __DIR__ . '/../includes/header.php';
?>

<style>
*, *::before, *::after { box-sizing: border-box; }

.rp-wrap { display: flex; flex-direction: column; gap: 20px; padding-bottom: 32px; }

/* ── Stat grid ── */
.rp-stat-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
  gap: 10px;
}
.rp-stat-card {
  background: #fff;
  border: 0.5px solid rgba(0,0,0,.08);
  border-radius: 14px;
  padding: 16px 18px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  transition: box-shadow .18s, transform .18s;
}
.rp-stat-card:hover { box-shadow: 0 4px 18px rgba(0,0,0,.07); transform: translateY(-2px); }
.rp-stat-icon {
  width: 36px; height: 36px;
  border-radius: 10px;
  display: flex; align-items: center; justify-content: center;
  font-size: 18px;
}
.rp-stat-label { font-size: 10.5px; font-weight: 600; letter-spacing: .4px; text-transform: uppercase; color: #6b7280; }
.rp-stat-value { font-size: 26px; font-weight: 600; line-height: 1; color: #111827; letter-spacing: -.5px; }
.rp-stat-value.small-val { font-size: 18px; letter-spacing: -.3px; }

.sc-blue   .rp-stat-icon { background: #eff6ff; color: #2563eb; }
.sc-violet .rp-stat-icon { background: #f5f3ff; color: #7c3aed; }
.sc-green  .rp-stat-icon { background: #f0fdf4; color: #16a34a; }
.sc-red    .rp-stat-icon { background: #fef2f2; color: #dc2626; }

/* ── Charts row ── */
.rp-charts-row-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
@media (max-width: 768px) { .rp-charts-row-2 { grid-template-columns: 1fr; } }

/* ── Card ── */
.rp-card { background: #fff; border: 0.5px solid rgba(0,0,0,.08); border-radius: 14px; padding: 18px 20px; }
.rp-card-title {
  font-size: 11.5px; font-weight: 600; letter-spacing: .3px;
  text-transform: uppercase; color: #6b7280;
  display: flex; align-items: center; gap: 7px;
  margin-bottom: 16px;
}
.rp-card-title i { font-size: 15px; }

/* ── Export buttons ── */
.rp-export-grid {
  display: flex; flex-wrap: wrap; gap: 10px;
}
.rp-export-btn {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 18px;
  border-radius: 10px;
  font-size: 13px; font-weight: 500;
  text-decoration: none;
  border: 0.5px solid transparent;
  transition: background .15s, transform .1s, box-shadow .15s;
  cursor: pointer;
}
.rp-export-btn:hover  { transform: translateY(-1px); box-shadow: 0 3px 10px rgba(0,0,0,.1); }
.rp-export-btn:active { transform: scale(.97); }

.btn-excel { background: #f0fdf4; color: #15803d; border-color: #bbf7d0; }
.btn-excel:hover { background: #dcfce7; }
.btn-pdf   { background: #fef2f2; color: #b91c1c; border-color: #fecaca; }
.btn-pdf:hover { background: #fee2e2; }
.btn-borrow { background: #eff6ff; color: #1d4ed8; border-color: #bfdbfe; }
.btn-borrow:hover { background: #dbeafe; }
.btn-maint  { background: #fffbeb; color: #b45309; border-color: #fde68a; }
.btn-maint:hover  { background: #fef3c7; }

/* ── Legend ── */
.rp-legend  { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px; }
.rp-leg     { display: flex; align-items: center; gap: 5px; font-size: 12px; color: #6b7280; }
.rp-leg-dot { width: 9px; height: 9px; border-radius: 2px; flex-shrink: 0; }
</style>

<div class="rp-wrap">

  <!-- ══ Stat Cards ══ -->
  <div class="rp-stat-grid">
    <div class="rp-stat-card sc-blue">
      <div class="rp-stat-icon"><i class="bi bi-arrow-left-right"></i></div>
      <div class="rp-stat-label">Total Borrow Records</div>
      <div class="rp-stat-value" data-target="<?= $borrow_total ?>">0</div>
    </div>
    <div class="rp-stat-card sc-violet">
      <div class="rp-stat-icon"><i class="bi bi-tools"></i></div>
      <div class="rp-stat-label">Maintenance Records</div>
      <div class="rp-stat-value" data-target="<?= $maint_total ?>">0</div>
    </div>
    <div class="rp-stat-card sc-green">
      <div class="rp-stat-icon"><i class="bi bi-cash-stack"></i></div>
      <div class="rp-stat-label">Total Maint. Cost</div>
      <div class="rp-stat-value small-val">RM <?= number_format($maint_cost, 2) ?></div>
    </div>
    <div class="rp-stat-card sc-red">
      <div class="rp-stat-icon"><i class="bi bi-exclamation-triangle"></i></div>
      <div class="rp-stat-label">Damaged / Disposed</div>
      <div class="rp-stat-value" data-target="<?= $damaged ?>">0</div>
    </div>
  </div>

  <!-- ══ Charts Row 1 — Category & Department ══ -->
  <div class="rp-charts-row-2">

    <div class="rp-card">
      <div class="rp-card-title"><i class="bi bi-pie-chart-fill" style="color:#6366f1"></i> Assets by Category</div>
      <div style="position:relative;width:100%;height:220px">
        <canvas id="c1"></canvas>
      </div>
      <div class="rp-legend" id="catLegend"></div>
    </div>

    <div class="rp-card">
      <div class="rp-card-title"><i class="bi bi-bar-chart-fill" style="color:#6366f1"></i> Assets by Department</div>
      <div style="position:relative;width:100%;height:260px">
        <canvas id="c2"></canvas>
      </div>
    </div>

  </div>

  <!-- ══ Chart Row 2 — Status ══ -->
  <div class="rp-card">
    <div class="rp-card-title"><i class="bi bi-graph-up" style="color:#6366f1"></i> Assets by Status</div>
    <div style="position:relative;width:100%;height:160px">
      <canvas id="c3"></canvas>
    </div>
  </div>

  <!-- ══ Quick Exports ══ -->
  <div class="rp-card">
    <div class="rp-card-title"><i class="bi bi-download" style="color:#6366f1"></i> Quick Exports</div>
    <div class="rp-export-grid">
      <a class="rp-export-btn btn-excel" href="<?= BASE_URL ?>assets/export.php?type=excel">
        <i class="bi bi-file-earmark-excel"></i> Asset List (Excel)
      </a>
      <a class="rp-export-btn btn-pdf" href="<?= BASE_URL ?>assets/export.php?type=pdf">
        <i class="bi bi-file-earmark-pdf"></i> Asset List (PDF)
      </a>
      <a class="rp-export-btn btn-borrow" href="export.php?type=borrow">
        <i class="bi bi-arrow-left-right"></i> Borrow Report
      </a>
      <a class="rp-export-btn btn-maint" href="export.php?type=maintenance">
        <i class="bi bi-tools"></i> Maintenance Report
      </a>
    </div>
  </div>

</div>

<!-- ══ Chart.js — MESTI load sebelum script chart ══ -->
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
/* ── Data dari PHP ── */
var byCategory = <?= json_encode($by_cat,    JSON_FORCE_OBJECT) ?>;
var byDept     = <?= json_encode($by_dep,    JSON_FORCE_OBJECT) ?>;
var byStatus   = <?= json_encode($by_status, JSON_FORCE_OBJECT) ?>;

/* ── Counter animation ── */
(function () {
  var cards   = document.querySelectorAll('.rp-stat-value[data-target]');
  var started = false;
  function run() {
    if (started) return;
    started = true;
    var t0 = performance.now(), dur = 900;
    function tick(ts) {
      var p    = Math.min((ts - t0) / dur, 1);
      var ease = 1 - Math.pow(1 - p, 3);
      cards.forEach(function(el) {
        el.textContent = Math.round(parseInt(el.dataset.target, 10) * ease);
      });
      if (p < 1) requestAnimationFrame(tick);
    }
    requestAnimationFrame(tick);
  }
  if ('IntersectionObserver' in window && cards.length) {
    new IntersectionObserver(function(e) { if (e[0].isIntersecting) run(); }, { threshold: 0.1 }).observe(cards[0]);
  } else { run(); }
})();

/* ── Colour palettes ── */
var palette = ['#6366f1','#10b981','#f59e0b','#ef4444','#8b5cf6','#06b6d4','#ec4899','#14b8a6'];

/* ── Donut — By Category ── */
var catKeys = Object.keys(byCategory);
var catVals = Object.values(byCategory);

if (catKeys.length > 0) {
  var catColors = catKeys.map(function(_, i) { return palette[i % palette.length]; });

  new Chart(document.getElementById('c1'), {
    type: 'doughnut',
    data: {
      labels: catKeys,
      datasets: [{ data: catVals, backgroundColor: catColors, borderWidth: 0, hoverOffset: 5 }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '65%',
      plugins: {
        legend: { display: false },
        tooltip: {
          callbacks: {
            label: function(ctx) {
              var tot = ctx.dataset.data.reduce(function(a, b) { return a + b; }, 0);
              return ' ' + ctx.label + ': ' + ctx.raw + ' (' + Math.round(ctx.raw / tot * 100) + '%)';
            }
          }
        }
      }
    }
  });

  /* Legend */
  var legendEl = document.getElementById('catLegend');
  var catTotal = catVals.reduce(function(a, b) { return a + b; }, 0);
  catKeys.forEach(function(k, i) {
    legendEl.insertAdjacentHTML('beforeend',
      '<span class="rp-leg">' +
        '<span class="rp-leg-dot" style="background:' + catColors[i] + '"></span>' +
        k + ' <strong style="margin-left:2px;color:#374151">' + Math.round(catVals[i] / catTotal * 100) + '%</strong>' +
      '</span>'
    );
  });
}

/* ── Bar — By Department ── */
var depKeys = Object.keys(byDept);
var depVals = Object.values(byDept);

if (depKeys.length > 0) {
  new Chart(document.getElementById('c2'), {
    type: 'bar',
    data: {
      labels: depKeys,
      datasets: [{
        label: 'Assets',
        data: depVals,
        backgroundColor: 'rgba(99,102,241,.80)',
        hoverBackgroundColor: 'rgba(99,102,241,1)',
        borderRadius: 6,
        borderSkipped: false
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        y: {
          beginAtZero: true,
          ticks: { precision: 0, font: { size: 11 }, color: '#9ca3af' },
          grid: { color: 'rgba(0,0,0,.04)' }
        },
        x: {
          ticks: { font: { size: 11 }, color: '#6b7280', autoSkip: false },
          grid: { display: false }
        }
      }
    }
  });
}

/* ── Line — By Status ── */
var statusColorMap = {
  'Available'   : '#16a34a',
  'Used By'     : '#7c3aed',
  'Borrowed'    : '#d97706',
  'Maintenance' : '#2563eb',
  'Damaged'     : '#dc2626',
  'Disposed'    : '#9ca3af'
};

var stKeys = Object.keys(byStatus);
var stVals = Object.values(byStatus);

if (stKeys.length > 0) {
  var stColors = stKeys.map(function(k) { return statusColorMap[k] || '#6366f1'; });

  new Chart(document.getElementById('c3'), {
    type: 'bar',
    data: {
      labels: stKeys,
      datasets: [{
        label: 'Assets',
        data: stVals,
        backgroundColor: stColors,
        borderRadius: 8,
        borderSkipped: false
      }]
    },
    options: {
      indexAxis: 'y',
      responsive: true,
      maintainAspectRatio: false,
      plugins: { legend: { display: false } },
      scales: {
        x: {
          beginAtZero: true,
          ticks: { precision: 0, font: { size: 11 }, color: '#9ca3af' },
          grid: { color: 'rgba(0,0,0,.04)' }
        },
        y: {
          ticks: { font: { size: 12 }, color: '#374151' },
          grid: { display: false }
        }
      }
    }
  });
}
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>