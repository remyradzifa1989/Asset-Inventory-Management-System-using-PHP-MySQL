<?php
require_once __DIR__ . '/../includes/config.php';
require_login();

$type = $_GET['type'] ?? 'borrow';

if ($type === 'borrow') {
    $title    = 'Borrow Report';
    $subtitle = 'All borrow records in the system';
    $rows     = $conn->query("SELECT b.*, a.asset_code, a.asset_name FROM borrow_records b LEFT JOIN assets a ON a.id=b.asset_id ORDER BY b.id DESC");
    $cols     = ['#', 'Asset Code', 'Asset Name', 'Borrowed By', 'Department', 'Borrow Date', 'Return Date', 'Status'];
    $map      = fn($r) => [
        $r['id'],
        $r['asset_code'],
        $r['asset_name'],
        $r['borrow_by'],
        $r['department'] ?: '—',
        $r['borrow_date'] ?: '—',
        $r['return_date'] ?: '—',
        $r['status'],
    ];

    /* Summary stats */
    $total    = (int)$conn->query("SELECT COUNT(*) c FROM borrow_records")->fetch_assoc()['c'];
    $active   = (int)$conn->query("SELECT COUNT(*) c FROM borrow_records WHERE status='Active'")->fetch_assoc()['c'];
    $returned = (int)$conn->query("SELECT COUNT(*) c FROM borrow_records WHERE status='Returned'")->fetch_assoc()['c'];
    $overdue  = (int)$conn->query("SELECT COUNT(*) c FROM borrow_records WHERE status='Overdue'")->fetch_assoc()['c'];
    $summaries = [
        ['label' => 'Total Records', 'value' => $total,    'icon' => '📋'],
        ['label' => 'Active',        'value' => $active,   'icon' => '🔄'],
        ['label' => 'Returned',      'value' => $returned, 'icon' => '✅'],
        ['label' => 'Overdue',       'value' => $overdue,  'icon' => '⚠️'],
    ];

} else {
    $title    = 'Maintenance Report';
    $subtitle = 'All maintenance records in the system';
    $rows     = $conn->query("SELECT m.*, a.asset_code, a.asset_name FROM maintenance_records m LEFT JOIN assets a ON a.id=m.asset_id ORDER BY m.id DESC");
    $cols     = ['#', 'Asset Code', 'Asset Name', 'Technician', 'Problem', 'Date', 'Cost (RM)', 'Status'];
    $map      = fn($r) => [
        $r['id'],
        $r['asset_code'],
        $r['asset_name'],
        $r['technician'] ?: '—',
        $r['problem'] ?: '—',
        $r['maintenance_date'] ?: '—',
        number_format((float)$r['cost'], 2),
        $r['status'],
    ];

    /* Summary stats */
    $total      = (int)$conn->query("SELECT COUNT(*) c FROM maintenance_records")->fetch_assoc()['c'];
    $pending    = (int)$conn->query("SELECT COUNT(*) c FROM maintenance_records WHERE status='Pending'")->fetch_assoc()['c'];
    $inprog     = (int)$conn->query("SELECT COUNT(*) c FROM maintenance_records WHERE status='In Progress'")->fetch_assoc()['c'];
    $completed  = (int)$conn->query("SELECT COUNT(*) c FROM maintenance_records WHERE status='Completed'")->fetch_assoc()['c'];
    $total_cost = (float)$conn->query("SELECT IFNULL(SUM(cost),0) s FROM maintenance_records")->fetch_assoc()['s'];
    $summaries = [
        ['label' => 'Total Records', 'value' => $total,                          'icon' => '📋'],
        ['label' => 'Pending',       'value' => $pending,                         'icon' => '⏳'],
        ['label' => 'In Progress',   'value' => $inprog,                          'icon' => '🔧'],
        ['label' => 'Total Cost',    'value' => 'RM ' . number_format($total_cost, 2), 'icon' => '💰'],
    ];
}

/* Collect all rows into array so we can count */
$data = [];
while ($r = $rows->fetch_assoc()) $data[] = $r;
$row_count = count($data);

/* Status badge colour helper */
function status_class(string $s): string {
    return match(strtolower(str_replace(' ', '-', $s))) {
        'active'      => 'b-active',
        'returned'    => 'b-returned',
        'overdue'     => 'b-overdue',
        'available'   => 'b-available',
        'borrowed'    => 'b-borrowed',
        'maintenance' => 'b-maintenance',
        'pending'     => 'b-pending',
        'in-progress' => 'b-inprogress',
        'completed'   => 'b-completed',
        'damaged'     => 'b-damaged',
        default       => 'b-default',
    };
}

/* Status column is always last */
$status_col_index = count($cols) - 1;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= e($title) ?> · AIMS</title>
<style>
/* ── Base ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
body {
  font-family: 'Segoe UI', Arial, sans-serif;
  font-size: 13px;
  color: #0f172a;
  background: #f1f5f9;
  padding: 0;
}

/* ── Top bar (no-print) ── */
.topbar {
  background: #fff;
  border-bottom: 0.5px solid #e2e8f0;
  padding: 12px 32px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  z-index: 100;
}
.topbar-left { display: flex; align-items: center; gap: 12px; }
.topbar-brand {
  font-size: 15px; font-weight: 700;
  color: #6366f1; letter-spacing: -.2px;
}
.topbar-sep { color: #cbd5e1; }
.topbar-title { font-size: 14px; color: #374151; font-weight: 500; }
.topbar-right { display: flex; align-items: center; gap: 8px; }

.btn-back, .btn-print {
  display: inline-flex; align-items: center; gap: 6px;
  padding: 8px 16px; border-radius: 9px;
  font-size: 13px; font-weight: 500;
  cursor: pointer; border: none; text-decoration: none;
  transition: background .15s, transform .1s;
}
.btn-back  { background: #f1f5f9; color: #374151; border: 0.5px solid #e2e8f0; }
.btn-back:hover  { background: #e2e8f0; }
.btn-print { background: #6366f1; color: #fff; }
.btn-print:hover { background: #4f46e5; }
.btn-print:active, .btn-back:active { transform: scale(.97); }

/* ── Page container ── */
.page {
  max-width: 1100px;
  margin: 28px auto;
  padding: 0 24px 40px;
}

/* ── Report header ── */
.rp-header {
  background: #fff;
  border: 0.5px solid rgba(0,0,0,.07);
  border-radius: 14px;
  padding: 22px 26px;
  margin-bottom: 16px;
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}
.rp-title-block h1 { font-size: 20px; font-weight: 700; letter-spacing: -.3px; color: #0f172a; }
.rp-title-block p  { font-size: 12.5px; color: #64748b; margin-top: 4px; }
.rp-meta { text-align: right; font-size: 12px; color: #94a3b8; line-height: 1.7; }
.rp-meta strong { color: #475569; }

/* ── Summary cards ── */
.rp-summary {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 10px;
  margin-bottom: 16px;
}
.rp-sum-card {
  background: #fff;
  border: 0.5px solid rgba(0,0,0,.07);
  border-radius: 12px;
  padding: 14px 16px;
  display: flex;
  align-items: center;
  gap: 12px;
}
.rp-sum-icon { font-size: 22px; line-height: 1; }
.rp-sum-label { font-size: 10.5px; font-weight: 600; text-transform: uppercase; letter-spacing: .3px; color: #6b7280; }
.rp-sum-value { font-size: 20px; font-weight: 700; color: #0f172a; letter-spacing: -.4px; margin-top: 2px; }

/* ── Table card ── */
.rp-table-card {
  background: #fff;
  border: 0.5px solid rgba(0,0,0,.07);
  border-radius: 14px;
  overflow: hidden;
}
.rp-table-head {
  padding: 14px 20px;
  border-bottom: 0.5px solid #e2e8f0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.rp-table-head-title {
  font-size: 12px; font-weight: 600;
  text-transform: uppercase; letter-spacing: .3px; color: #6b7280;
}
.rp-row-count {
  font-size: 12px; color: #94a3b8;
  background: #f8fafc; border: 0.5px solid #e2e8f0;
  border-radius: 20px; padding: 2px 10px;
}

/* ── Table ── */
.rp-tbl { width: 100%; border-collapse: collapse; font-size: 12.5px; }
.rp-tbl th {
  background: #f8fafc;
  padding: 10px 14px;
  text-align: left;
  font-size: 10.5px; font-weight: 600;
  color: #6b7280; letter-spacing: .3px;
  text-transform: uppercase;
  border-bottom: 0.5px solid #e2e8f0;
  white-space: nowrap;
}
.rp-tbl td {
  padding: 10px 14px;
  border-bottom: 0.5px solid #f1f5f9;
  color: #374151;
  vertical-align: middle;
}
.rp-tbl tr:last-child td { border-bottom: none; }
.rp-tbl tr:hover td { background: #fafafa; }
.rp-tbl .col-id { color: #94a3b8; font-family: ui-monospace, monospace; font-size: 11.5px; }
.rp-tbl .col-code { font-weight: 600; font-family: ui-monospace, monospace; font-size: 12px; color: #0f172a; }

/* ── Status badges ── */
.badge {
  display: inline-block; padding: 2px 10px;
  border-radius: 20px; font-size: 10.5px; font-weight: 600;
}
.b-active      { background: #fdf4ff; color: #86198f; }
.b-returned    { background: #f0fdf4; color: #15803d; }
.b-overdue     { background: #fef2f2; color: #b91c1c; }
.b-available   { background: #f0fdf4; color: #15803d; }
.b-borrowed    { background: #fffbeb; color: #b45309; }
.b-maintenance { background: #eff6ff; color: #1d4ed8; }
.b-pending     { background: #fffbeb; color: #b45309; }
.b-inprogress  { background: #eff6ff; color: #1d4ed8; }
.b-completed   { background: #f0fdf4; color: #15803d; }
.b-damaged     { background: #fef2f2; color: #b91c1c; }
.b-default     { background: #f1f5f9; color: #64748b; }

/* ── Empty state ── */
.rp-empty {
  text-align: center; padding: 48px 20px;
  color: #94a3b8; font-size: 13px;
}

/* ── Print styles ── */
@media print {
  .no-print { display: none !important; }
  body { background: #fff; }
  .page { margin: 0; padding: 12px; max-width: 100%; }
  .rp-header, .rp-sum-card, .rp-table-card { border: 0.5px solid #cbd5e1 !important; border-radius: 0 !important; }
  .rp-tbl th { background: #e2e8f0 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .rp-tbl tr:hover td { background: transparent !important; }
  .badge { border: 0.5px solid currentColor; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  .rp-summary { grid-template-columns: repeat(4, 1fr); }
  @page { margin: 15mm; }
}
</style>
</head>
<body>

<!-- Top bar -->
<div class="topbar no-print">
  <div class="topbar-left">
    <span class="topbar-brand">AIMS</span>
    <span class="topbar-sep">›</span>
    <span class="topbar-title"><?= e($title) ?></span>
  </div>
  <div class="topbar-right">
    <a class="btn-back" href="javascript:history.back()">← Back</a>
    <button class="btn-print" onclick="window.print()">🖨️ Print / Save PDF</button>
  </div>
</div>

<div class="page">

  <!-- Report header -->
  <div class="rp-header">
    <div class="rp-title-block">
      <h1><?= e($title) ?></h1>
      <p><?= e($subtitle) ?></p>
    </div>
    <div class="rp-meta">
      <div>Generated: <strong><?= date('d M Y, H:i') ?></strong></div>
      <div>Total Records: <strong><?= $row_count ?></strong></div>
      <div>System: <strong><?= APP_NAME ?></strong></div>
    </div>
  </div>

  <!-- Summary cards -->
  <div class="rp-summary">
    <?php foreach ($summaries as $s): ?>
    <div class="rp-sum-card">
      <div class="rp-sum-icon"><?= $s['icon'] ?></div>
      <div>
        <div class="rp-sum-label"><?= e($s['label']) ?></div>
        <div class="rp-sum-value"><?= e((string)$s['value']) ?></div>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

  <!-- Table -->
  <div class="rp-table-card">
    <div class="rp-table-head">
      <span class="rp-table-head-title">📄 Records</span>
      <span class="rp-row-count"><?= $row_count ?> rows</span>
    </div>

    <?php if ($row_count === 0): ?>
      <div class="rp-empty">No records found.</div>
    <?php else: ?>
    <div style="overflow-x:auto">
      <table class="rp-tbl">
        <thead>
          <tr>
            <?php foreach ($cols as $i => $c): ?>
            <th><?= e($c) ?></th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($data as $r): ?>
          <?php $cells = $map($r); ?>
          <tr>
            <?php foreach ($cells as $i => $v): ?>
            <?php if ($i === 0): ?>
              <td class="col-id"><?= e((string)$v) ?></td>
            <?php elseif ($i === 1): ?>
              <td class="col-code"><?= e((string)$v) ?></td>
            <?php elseif ($i === $status_col_index): ?>
              <td><span class="badge <?= status_class((string)$v) ?>"><?= e((string)$v) ?></span></td>
            <?php else: ?>
              <td><?= e((string)$v) ?></td>
            <?php endif; ?>
            <?php endforeach; ?>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endif; ?>
  </div>

</div><!-- /page -->
</body>
</html>