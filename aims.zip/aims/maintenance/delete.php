<?php
require_once __DIR__ . '/../includes/config.php';
require_admin();
$id=(int)$_GET['id'];
$conn->query("DELETE FROM maintenance_records WHERE id=$id");
header('Location: list.php'); exit;
