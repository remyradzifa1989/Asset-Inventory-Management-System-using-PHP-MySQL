<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$id=(int)$_GET['id'];
$m=$conn->query("SELECT * FROM maintenance_records WHERE id=$id")->fetch_assoc();
if ($m) {
    $conn->query("UPDATE maintenance_records SET status='Completed' WHERE id=$id");
    $conn->query("UPDATE assets SET status='Available' WHERE id=".(int)$m['asset_id']);
    log_activity($_SESSION['user_id'],'MAINT_COMPLETE','Completed maintenance #'.$id);
}
header('Location: list.php'); exit;
