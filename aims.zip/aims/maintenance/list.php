<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$page_title = 'Maintenance Records';
$active     = 'maintenance';

// --- FILTERS ---
$search     = trim($_GET['search']     ?? '');
$ftech      = trim($_GET['technician'] ?? '');
$fstatus    = trim($_GET['status']     ?? '');
$fdate_from = trim($_GET['date_from']  ?? '');
$fdate_to   = trim($_GET['date_to']    ?? '');
$fcost_min  = trim($_GET['cost_min']   ?? '');
$fcost_max  = trim($_GET['cost_max']   ?? '');

$where = []; $params = []; $types = '';

if ($search !== '') {
    $where[] = '(a.asset_name LIKE ? OR a.asset_code LIKE ?)';
    $like = "%$search%";
    $params[] = $like; $params[] = $like; $types .= 'ss';
}
if ($ftech !== '') {
    $where[] = 'm.technician LIKE ?';
    $params[] = "%$ftech%"; $types .= 's';
}
if ($fstatus !== '') {
    $where[] = 'm.status = ?';
    $params[] = $fstatus; $types .= 's';
}
if ($fdate_from !== '') {
    $where[] = 'm.maintenance_date >= ?';
    $params[] = $fdate_from; $types .= 's';
}
if ($fdate_to !== '') {
    $where[] = 'm.maintenance_date <= ?';
    $params[] = $fdate_to; $types .= 's';
}
if ($fcost_min !== '') {
    $where[] = 'm.cost >= ?';
    $params[] = (float)$fcost_min; $types .= 'd';
}
if ($fcost_max !== '') {
    $where[] = 'm.cost <= ?';
    $params[] = (float)$fcost_max; $types .= 'd';
}

$sql = "SELECT m.*, a.asset_code, a.asset_name
        FROM maintenance_records m
        LEFT JOIN assets a ON a.id = m.asset_id"
     . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
     . " ORDER BY m.id DESC";

$stmt = $conn->prepare($sql);
if ($params) $stmt->bind_param($types, ...$params);
$stmt->execute();
$all = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// ── ACTIVE FILTERS label ──
$active_filters = array_filter([
    $search     ? "Asset: \"$search\""     : '',
    $ftech      ? "Technician: \"$ftech\"" : '',
    $fstatus    ? "Status: $fstatus"       : '',
    $fdate_from ? "From: $fdate_from"      : '',
    $fdate_to   ? "To: $fdate_to"         : '',
    $fcost_min  ? "Min: RM$fcost_min"      : '',
    $fcost_max  ? "Max: RM$fcost_max"      : '',
]);

// ── EXCEL EXPORT ──
if (isset($_GET['export']) && $_GET['export'] === 'excel') {
    header('Content-Type: application/vnd.ms-excel');
    header('Content-Disposition: attachment;filename="maintenance_' . date('Ymd_His') . '.xls"');
    header('Cache-Control: max-age=0');
    echo '<table border="1">';
    echo '<tr><th colspan="8" style="font-size:14px;font-weight:bold;text-align:center;background:#1a3c6e;color:#fff">MAINTENANCE RECORDS</th></tr>';
    echo '<tr><th colspan="8" style="text-align:center;color:#555;font-size:11px">Generated: ' . date('d M Y, h:i A') . '</th></tr>';
    echo '<tr><th colspan="8"></th></tr>';
    echo '<tr style="background:#1a3c6e;color:#fff">
            <th>No.</th><th>Asset Code</th><th>Asset Name</th><th>Technician</th>
            <th>Problem</th><th>Date</th><th>Cost (RM)</th><th>Status</th>
          </tr>';
    $i = 1;
    foreach ($all as $m) {
        echo '<tr>';
        echo '<td>' . $i++ . '</td>';
        echo '<td>' . htmlspecialchars($m['asset_code'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($m['asset_name'] ?? '') . '</td>';
        echo '<td>' . htmlspecialchars($m['technician']) . '</td>';
        echo '<td>' . htmlspecialchars($m['problem']) . '</td>';
        echo '<td>' . htmlspecialchars($m['maintenance_date']) . '</td>';
        echo '<td style="text-align:right">' . number_format((float)$m['cost'], 2) . '</td>';
        echo '<td>' . htmlspecialchars($m['status']) . '</td>';
        echo '</tr>';
    }
    $total = array_sum(array_column($all, 'cost'));
    echo '<tr style="font-weight:bold;background:#f0f0f0">
            <td colspan="6" style="text-align:right">TOTAL COST (RM)</td>
            <td style="text-align:right">' . number_format($total, 2) . '</td>
            <td></td>
          </tr>';
    echo '</table>';
    exit;
}

// ── PDF EXPORT ──
if (isset($_GET['export']) && $_GET['export'] === 'pdf') {
    $total        = array_sum(array_column($all, 'cost'));
    $filter_label = $active_filters ? implode(' &nbsp;|&nbsp; ', $active_filters) : 'All Records';
    $rows_html    = '';
    $i = 1;
    foreach ($all as $m) {
        $status_color = match($m['status']) {
            'Completed'   => '#16a34a',
            'In Progress' => '#d97706',
            default       => '#dc2626',
        };
        $rows_html .= '<tr>
            <td style="text-align:center">'   . $i++ . '</td>
            <td><strong>' . htmlspecialchars($m['asset_code'] ?? '') . '</strong></td>
            <td>'  . htmlspecialchars($m['asset_name'] ?? '') . '</td>
            <td>'  . htmlspecialchars($m['technician']) . '</td>
            <td>'  . htmlspecialchars(mb_strimwidth($m['problem'], 0, 80, '...')) . '</td>
            <td style="text-align:center">' . htmlspecialchars($m['maintenance_date']) . '</td>
            <td style="text-align:right">RM ' . number_format((float)$m['cost'], 2) . '</td>
            <td style="text-align:center"><span style="background:' . $status_color . ';color:#fff;padding:2px 8px;border-radius:999px;font-size:10px;font-weight:600">' . htmlspecialchars($m['status']) . '</span></td>
        </tr>';
    }
    // PDF HTML output (unchanged from original)
    echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
    <style>
        *{margin:0;padding:0;box-sizing:border-box}
        body{font-family:"Segoe UI",Arial,sans-serif;font-size:11px;color:#1e293b;background:#f8fafc;padding:30px}
        .card{background:#fff;border-radius:12px;box-shadow:0 1px 8px rgba(0,0,0,.08);overflow:hidden}
        .pdf-header{background:linear-gradient(135deg,#1a3c6e 0%,#2563eb 100%);padding:24px 28px;color:#fff}
        .pdf-header h1{font-size:20px;font-weight:700;letter-spacing:.5px}
        .pdf-header p{font-size:11px;opacity:.8;margin-top:4px}
        .pdf-meta{display:flex;gap:20px;margin-top:12px;flex-wrap:wrap}
        .pdf-meta span{background:rgba(255,255,255,.15);padding:4px 10px;border-radius:6px;font-size:10px}
        .filter-bar{padding:10px 28px;background:#eff6ff;border-bottom:1px solid #dbeafe;font-size:10px;color:#3b82f6}
        .filter-bar strong{color:#1d4ed8}
        table{width:100%;border-collapse:collapse}
        thead tr{background:#1a3c6e}
        thead th{color:#fff;padding:9px 10px;font-size:10px;font-weight:600;letter-spacing:.3px;white-space:nowrap}
        tbody tr:nth-child(even){background:#f8fafc}
        tbody td{padding:8px 10px;border-bottom:1px solid #e2e8f0;vertical-align:middle}
        .total-row td{background:#1a3c6e;color:#fff;font-weight:700;padding:9px 10px}
        .pdf-footer{padding:12px 28px;text-align:right;font-size:10px;color:#94a3b8;border-top:1px solid #e2e8f0}
        .no-print{padding:16px 28px;display:flex;gap:10px;background:#f1f5f9;border-bottom:1px solid #e2e8f0}
        .btn-print{display:inline-flex;align-items:center;gap:6px;padding:8px 18px;border-radius:8px;font-size:12px;font-weight:600;cursor:pointer;border:none}
        .btn-pdf{background:#dc2626;color:#fff}
        .btn-close{background:#e2e8f0;color:#475569}
        @media print{body{background:#fff;padding:0}.no-print{display:none!important}.card{box-shadow:none;border-radius:0}}
    </style></head><body>
    <div class="card">
        <div class="no-print">
            <button class="btn-print btn-pdf" onclick="window.print()">🖨&nbsp; Print / Save as PDF</button>
            <button class="btn-print btn-close" onclick="window.close()">✕&nbsp; Close</button>
        </div>
        <div class="pdf-header">
            <h1>🔧 Maintenance Records</h1>
            <p>Asset Integrated Management System (AIMS)</p>
            <div class="pdf-meta">
                <span>📅 Generated: ' . date('d M Y, h:i A') . '</span>
                <span>📋 Total Records: ' . count($all) . '</span>
                <span>💰 Total Cost: RM ' . number_format($total, 2) . '</span>
            </div>
        </div>
        <div class="filter-bar"><strong>Filter Applied:</strong>&nbsp; ' . htmlspecialchars($filter_label) . '</div>
        <div>
        <table>
            <thead>
                <tr>
                    <th style="width:40px;text-align:center">No.</th>
                    <th style="width:90px">Asset Code</th>
                    <th>Asset Name</th>
                    <th style="width:110px">Technician</th>
                    <th>Problem</th>
                    <th style="width:90px;text-align:center">Date</th>
                    <th style="width:90px;text-align:right">Cost (RM)</th>
                    <th style="width:85px;text-align:center">Status</th>
                </tr>
            </thead>
            <tbody>
                ' . $rows_html . '
                <tr class="total-row">
                    <td colspan="6" style="text-align:right;letter-spacing:.5px">TOTAL COST</td>
                    <td style="text-align:right">RM ' . number_format($total, 2) . '</td>
                    <td></td>
                </tr>
            </tbody>
        </table>
        </div>
        <div class="pdf-footer">AIMS &mdash; Maintenance Records Report &mdash; ' . date('Y') . '</div>
    </div>
    </body></html>';
    exit;
}

include __DIR__ . '/../includes/header.php';

// Compute totals for display
$grand_total    = array_sum(array_column($all, 'cost'));
$total_records  = count($all);
?>

<style>
/* ── Export button animations ── */
.btn-export {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 14px;
    border-radius: 8px;
    font-size: 12px;
    font-weight: 600;
    text-decoration: none;
    transition: all .2s ease;
    position: relative;
    overflow: hidden;
}
.btn-export::before {
    content: '';
    position: absolute;
    inset: 0;
    background: rgba(255,255,255,.15);
    transform: translateX(-100%);
    transition: transform .25s ease;
}
.btn-export:hover::before { transform: translateX(0); }
.btn-export:hover { transform: translateY(-1px); box-shadow: 0 4px 12px rgba(0,0,0,.2); }
.btn-export:active { transform: translateY(0); }
.btn-excel { background: linear-gradient(135deg,#166534,#16a34a); color:#fff; }
.btn-pdf   { background: linear-gradient(135deg,#991b1b,#dc2626); color:#fff; }

/* ── Filter card ── */
.filter-card {
    background: #fff;
    border: 1px solid #e2e8f0;
    border-radius: 12px;
    padding: 16px 20px;
    margin-bottom: 16px;
    box-shadow: 0 1px 4px rgba(0,0,0,.05);
}
.filter-title {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .6px;
    color: #94a3b8;
    margin-bottom: 12px;
    display: flex;
    align-items: center;
    gap: 6px;
}
.active-filters { display:flex; flex-wrap:wrap; gap:6px; margin-top:10px; }
.filter-badge {
    display: inline-flex;
    align-items: center;
    gap: 4px;
    padding: 3px 10px;
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    border-radius: 999px;
    font-size: 11px;
    color: #1d4ed8;
    font-weight: 500;
}

/* ── Export bar ── */
.export-bar {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    background: linear-gradient(90deg,#f8fafc,#eff6ff);
    border: 1px solid #e2e8f0;
    border-radius: 10px;
    margin-bottom: 12px;
}
.export-label {
    font-size: 11px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .5px;
    color: #94a3b8;
    margin-right: 4px;
    white-space: nowrap;
}
.export-info {
    margin-left: auto;
    font-size: 11px;
    color: #64748b;
    white-space: nowrap;
}
.export-info strong { color: #1e293b; }
</style>

<!-- ── PAGE HEADER ── -->
<div class="d-flex justify-content-between align-items-center mb-3">
  <div>
    <h5 class="mb-0"><i class="bi bi-tools text-primary"></i> Maintenance Records</h5>
    <p class="text-muted small mb-0 mt-1">Manage and track all asset maintenance activities</p>
  </div>
  <a href="form.php" class="btn btn-gradient"><i class="bi bi-plus-lg"></i> New Maintenance</a>
</div>

<!-- ── FILTER CARD ── -->
<div class="filter-card">
  <div class="filter-title"><i class="bi bi-funnel-fill text-primary"></i> Search & Filter</div>
  <form method="GET" class="row g-2 align-items-end">
    <div class="col-md-3">
      <label class="form-label small mb-1 fw-semibold">Asset Name / Code</label>
      <div class="input-group input-group-sm">
        <span class="input-group-text"><i class="bi bi-search"></i></span>
        <input type="text" name="search" class="form-control" placeholder="Search asset..."
               value="<?= htmlspecialchars($search) ?>">
      </div>
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1 fw-semibold">Technician</label>
      <div class="input-group input-group-sm">
        <span class="input-group-text"><i class="bi bi-person"></i></span>
        <input type="text" name="technician" class="form-control" placeholder="Name..."
               value="<?= htmlspecialchars($ftech) ?>">
      </div>
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1 fw-semibold">Status</label>
      <select name="status" class="form-select form-select-sm">
        <option value="">All Status</option>
        <?php foreach (['Pending', 'In Progress', 'Completed'] as $s): ?>
          <option value="<?= $s ?>" <?= $fstatus === $s ? 'selected' : '' ?>><?= $s ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1 fw-semibold">Date From</label>
      <input type="date" name="date_from" class="form-control form-control-sm"
             value="<?= htmlspecialchars($fdate_from) ?>">
    </div>
    <div class="col-md-2">
      <label class="form-label small mb-1 fw-semibold">Date To</label>
      <input type="date" name="date_to" class="form-control form-control-sm"
             value="<?= htmlspecialchars($fdate_to) ?>">
    </div>
    <div class="col-md-1 col-6">
      <label class="form-label small mb-1 fw-semibold">Min (RM)</label>
      <input type="number" name="cost_min" step="0.01" class="form-control form-control-sm"
             placeholder="0" value="<?= htmlspecialchars($fcost_min) ?>">
    </div>
    <div class="col-md-1 col-6">
      <label class="form-label small mb-1 fw-semibold">Max (RM)</label>
      <input type="number" name="cost_max" step="0.01" class="form-control form-control-sm"
             placeholder="∞" value="<?= htmlspecialchars($fcost_max) ?>">
    </div>
    <div class="col-12 d-flex gap-2 pt-1">
      <button type="submit" class="btn btn-sm btn-primary px-3">
        <i class="bi bi-search"></i> Search
      </button>
      <a href="list.php" class="btn btn-sm btn-outline-secondary">
        <i class="bi bi-arrow-counterclockwise"></i> Reset
      </a>
    </div>
  </form>

  <?php if ($active_filters): ?>
  <div class="active-filters mt-2">
    <span class="text-muted small me-1"><i class="bi bi-funnel"></i> Active:</span>
    <?php foreach ($active_filters as $f): ?>
      <span class="filter-badge">
        <i class="bi bi-check-circle-fill" style="font-size:9px"></i>
        <?= htmlspecialchars($f) ?>
      </span>
    <?php endforeach; ?>
  </div>
  <?php endif; ?>
</div>

<!-- ── EXPORT BAR ── -->
<div class="export-bar">
  <span class="export-label"><i class="bi bi-download"></i> Export</span>
  <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'excel'])) ?>"
     class="btn-export btn-excel">
    <i class="bi bi-file-earmark-excel-fill"></i> Excel (.xls)
  </a>
  <a href="?<?= http_build_query(array_merge($_GET, ['export' => 'pdf'])) ?>"
     class="btn-export btn-pdf" target="_blank">
    <i class="bi bi-file-earmark-pdf-fill"></i> PDF / Print
  </a>
  <span class="export-info">
    <strong><?= $total_records ?></strong> record<?= $total_records !== 1 ? 's' : '' ?> &bull;
    Total: <strong>RM <?= number_format($grand_total, 2) ?></strong>
  </span>
</div>

<!-- ── TABLE ── -->
<!--
    FIX: Table mesti ada exactly 8 <th> dan setiap <tr> dalam tbody
         mesti ada exactly 8 <td>. Jangan letak colspan dalam tbody
         kecuali untuk empty state, dan pastikan bilangannya betul.

    SEBAB ERROR ASAL:
    - DataTables mengira kolum dari <thead>
    - Bila ada mismatch dengan <td> count dalam mana-mana row, error berlaku
    - colspan="8" dalam empty row OK tapi mesti betul-betul 8
-->
<div class="aims-table p-3">
  <table class="table aims-dt align-middle w-100" id="maintenanceTable">
    <thead>
      <tr>
        <th style="width:50px">No.</th>   <!-- kolum 1 -->
        <th>Asset</th>                     <!-- kolum 2 -->
        <th>Technician</th>               <!-- kolum 3 -->
        <th>Problem</th>                  <!-- kolum 4 -->
        <th>Date</th>                     <!-- kolum 5 -->
        <th>Cost (RM)</th>                <!-- kolum 6 -->
        <th>Status</th>                   <!-- kolum 7 -->
        <th style="width:90px">Actions</th> <!-- kolum 8 -->
      </tr>
    </thead>
    <tbody>
      <?php if (empty($all)): ?>
        <!-- Empty state: colspan mestilah sama dengan bilangan <th> = 8 -->
        <tr>
          <td colspan="8" class="text-center py-5 text-muted">
            <i class="bi bi-inbox fs-3 d-block mb-2"></i>
            No records found.
          </td>
        </tr>
      <?php else: ?>
        <?php $no = 1; foreach ($all as $m): ?>
          <tr>
            <!-- kolum 1: No -->
            <td class="text-muted small"><?= $no++ ?></td>

            <!-- kolum 2: Asset (code + name dalam satu cell) -->
            <td>
              <strong class="d-block"><?= htmlspecialchars($m['asset_code'] ?? '-') ?></strong>
              <small class="text-muted"><?= htmlspecialchars($m['asset_name'] ?? '-') ?></small>
            </td>

            <!-- kolum 3: Technician -->
            <td><?= htmlspecialchars($m['technician']) ?></td>

            <!-- kolum 4: Problem -->
            <td>
              <span title="<?= htmlspecialchars($m['problem']) ?>">
                <?= htmlspecialchars(mb_strimwidth($m['problem'], 0, 60, '...')) ?>
              </span>
            </td>

            <!-- kolum 5: Date -->
            <td><?= htmlspecialchars($m['maintenance_date']) ?></td>

            <!-- kolum 6: Cost -->
            <td class="fw-semibold text-nowrap">
              RM <?= number_format((float)$m['cost'], 2) ?>
            </td>

            <!-- kolum 7: Status -->
            <td>
              <span class="badge-status b-<?= strtolower(str_replace(' ', '-', $m['status'])) ?>">
                <?= htmlspecialchars($m['status']) ?>
              </span>
            </td>

            <!-- kolum 8: Actions — SENTIASA ada <td> ini, walaupun kosong -->
            <td>
              <?php if ($m['status'] !== 'Completed'): ?>
                <a href="complete.php?id=<?= (int)$m['id'] ?>"
                   class="btn btn-sm btn-success mb-1"
                   title="Mark Complete">
                  <i class="bi bi-check-lg"></i>
                </a>
              <?php endif; ?>
              <?php if ($_SESSION['role'] === 'ADMIN'): ?>
                <a href="delete.php?id=<?= (int)$m['id'] ?>"
                   class="btn btn-sm btn-outline-danger confirm-delete"
                   title="Delete">
                  <i class="bi bi-trash"></i>
                </a>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
      <?php endif; ?>
    </tbody>
  </table>
</div>

<script>
// Pastikan DataTables hanya diinisialisasi SEKALI sahaja.
// Gunakan $.fn.DataTable.isDataTable() untuk semak sebelum init.
$(document).ready(function () {
    var tableId = '#maintenanceTable';

    // Destroy dulu kalau dah wujud (elak "reinitialise" error)
    if ($.fn.DataTable.isDataTable(tableId)) {
        $(tableId).DataTable().destroy();
    }

    $(tableId).DataTable({
        // Disable DataTables built-in search/sort pada kolum Actions (kolum terakhir, index 7)
        columnDefs: [
            { orderable: false, searchable: false, targets: 7 }
        ],
        order: [],           // Jangan auto-sort
        pageLength: 25,
        language: {
            emptyTable:     'Tiada rekod dijumpai.',
            zeroRecords:    'Tiada rekod sepadan dengan carian.',
            info:           'Papar _START_ hingga _END_ daripada _TOTAL_ rekod',
            infoEmpty:      'Tiada rekod',
            infoFiltered:   '(ditapis daripada _MAX_ rekod)',
            search:         'Cari:',
            paginate: {
                first:    'Mula',
                last:     'Akhir',
                next:     'Seterusnya',
                previous: 'Sebelum'
            }
        },
        // Elak DataTables auto-process filter (kita dah buat server-side)
        searching: true,
        paging:    true,
        info:      true
    });
});
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>