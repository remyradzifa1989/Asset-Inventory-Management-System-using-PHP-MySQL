<?php
require_once __DIR__ . '/../includes/config.php';
require_login();
$page_title='Maintenance Form'; $active='maintenance';

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $aid=(int)$_POST['asset_id']; $tech=trim($_POST['technician']); $prob=trim($_POST['problem']);
    $md=$_POST['maintenance_date']; $cost=(float)$_POST['cost']; $st=$_POST['status']; $rm=trim($_POST['remarks']);
    $stmt=$conn->prepare("INSERT INTO maintenance_records (asset_id,technician,problem,maintenance_date,cost,status,remarks) VALUES (?,?,?,?,?,?,?)");
    $stmt->bind_param('isssdss',$aid,$tech,$prob,$md,$cost,$st,$rm); $stmt->execute();
    if ($st!=='Completed') $conn->query("UPDATE assets SET status='Maintenance' WHERE id=$aid");
    log_activity($_SESSION['user_id'],'MAINT_CREATE','Maintenance for asset #'.$aid);
    header('Location: list.php'); exit;
}
$assets = $conn->query("SELECT id,asset_code,asset_name FROM assets ORDER BY asset_code");
include __DIR__ . '/../includes/header.php';
?>
<form method="post">
<div class="form-section">
  <div class="form-section-title"><i class="bi bi-tools"></i> Maintenance Form</div>
  <div class="row g-3">
    <div class="col-md-6"><label class="form-label">Asset *</label>
      <select name="asset_id" class="form-select" required><option value="">-- Select --</option>
        <?php while($a=$assets->fetch_assoc()): ?><option value="<?= $a['id'] ?>"><?= e($a['asset_code']) ?> · <?= e($a['asset_name']) ?></option><?php endwhile; ?>
      </select>
    </div>
    <div class="col-md-6"><label class="form-label">Technician *</label><input class="form-control" name="technician" required></div>
    <div class="col-12"><label class="form-label">Problem Description *</label><textarea name="problem" class="form-control" rows="3" required></textarea></div>
    <div class="col-md-4"><label class="form-label">Maintenance Date *</label><input type="date" class="form-control" name="maintenance_date" value="<?= date('Y-m-d') ?>" required></div>
    <div class="col-md-4"><label class="form-label">Cost (RM)</label><input type="number" step="0.01" class="form-control" name="cost" value="0"></div>
    <div class="col-md-4"><label class="form-label">Status</label>
      <select name="status" class="form-select"><?php foreach(['Pending','In Progress','Completed'] as $s): ?><option><?= $s ?></option><?php endforeach; ?></select>
    </div>
    <div class="col-12"><label class="form-label">Remarks</label><textarea class="form-control" name="remarks" rows="2"></textarea></div>
  </div>
</div>
<button class="btn btn-gradient"><i class="bi bi-save"></i> Save</button>
<a href="list.php" class="btn btn-light">Cancel</a>
</form>
<?php include __DIR__ . '/../includes/footer.php'; ?>
